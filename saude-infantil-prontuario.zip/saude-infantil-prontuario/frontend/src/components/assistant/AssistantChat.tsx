'use client';

import { useState, useRef, useEffect } from 'react';
import api from '@/lib/api';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  data?: any;
}

const QUICK_QUESTIONS = [
  'Qual o horário das unidades?',
  'Meus agendamentos',
  'Status do meu atendimento',
  'Meus encaminhamentos',
];

export default function AssistantChat({
  childId,
  municipalityId,
}: {
  childId?: string;
  municipalityId: string;
}) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content:
        'Olá! Sou o assistente da sua unidade de saúde. Posso informar horários, ' +
        'profissionais disponíveis, seus agendamentos, status de atendimento, ' +
        'encaminhamentos e dados do Cartão SUS. Como posso ajudar?',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  async function send(text: string) {
    if (!text.trim()) return;
    const userMsg: Message = { role: 'user', content: text };
    setMessages((m) => [...m, userMsg]);
    setInput('');
    setLoading(true);

    try {
      // 1. Tenta resolver via backend (consultas estruturadas)
      const res = await api.post('/assistant/message', {
        message: text,
        childId,
        municipalityId,
      });
      const { message, data, needsAI } = res.data;

      if (needsAI) {
        // 2. Pergunta aberta → encaminha para IA (Claude)
        const aiReply = await askAI(text);
        setMessages((m) => [...m, { role: 'assistant', content: aiReply }]);
      } else {
        setMessages((m) => [...m, { role: 'assistant', content: message, data }]);
      }
    } catch {
      setMessages((m) => [
        ...m,
        { role: 'assistant', content: 'Desculpe, não consegui processar agora. Tente novamente.' },
      ]);
    } finally {
      setLoading(false);
    }
  }

  // Resposta livre via API do Claude
  async function askAI(question: string): Promise<string> {
    try {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6',
          max_tokens: 1000,
          messages: [
            {
              role: 'user',
              content:
                `Você é um assistente de uma unidade de saúde pública municipal no Brasil (SUS). ` +
                `Responda de forma clara, acolhedora e objetiva, em português. ` +
                `Se a pergunta envolver diagnóstico ou conduta médica, oriente a procurar um profissional. ` +
                `Pergunta do usuário: ${question}`,
            },
          ],
        }),
      });
      const data = await response.json();
      return data.content
        .filter((c: any) => c.type === 'text')
        .map((c: any) => c.text)
        .join('\n');
    } catch {
      return 'Para essa pergunta, recomendo entrar em contato com a sua unidade de saúde.';
    }
  }

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-blue-600 text-white rounded-full shadow-lg flex items-center justify-center hover:bg-blue-700 z-50"
        aria-label="Abrir assistente"
      >
        💬
      </button>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 w-80 sm:w-96 h-[520px] bg-white rounded-2xl shadow-2xl flex flex-col z-50 border border-gray-200">
      {/* Header */}
      <div className="bg-blue-600 text-white px-4 py-3 rounded-t-2xl flex items-center justify-between">
        <div>
          <p className="text-sm font-medium">Assistente de Saúde</p>
          <p className="text-xs text-blue-100">Online · resposta imediata</p>
        </div>
        <button onClick={() => setOpen(false)} className="text-white/80 hover:text-white" aria-label="Fechar">
          ✕
        </button>
      </div>

      {/* Mensagens */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-[80%] px-3 py-2 rounded-2xl text-sm ${
                m.role === 'user'
                  ? 'bg-blue-600 text-white rounded-br-sm'
                  : 'bg-gray-100 text-gray-800 rounded-bl-sm'
              }`}
            >
              <p className="whitespace-pre-wrap">{m.content}</p>
              {m.data && Array.isArray(m.data) && (
                <div className="mt-2 space-y-1">
                  {m.data.slice(0, 5).map((item: any, j: number) => (
                    <div key={j} className="text-xs bg-white/70 rounded p-2 text-gray-700">
                      {item.name && <span className="font-medium">{item.name}</span>}
                      {item.scheduledAt && <span> · {new Date(item.scheduledAt).toLocaleString('pt-BR')}</span>}
                      {item.specialty && <span> · {item.specialty}</span>}
                      {item.openingHours && <span className="block">{item.openingHours}</span>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-gray-100 px-3 py-2 rounded-2xl">
              <span className="inline-flex gap-1">
                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" />
                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:0.4s]" />
              </span>
            </div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Sugestões rápidas */}
      {messages.length <= 1 && (
        <div className="px-3 pb-2 flex flex-wrap gap-1.5">
          {QUICK_QUESTIONS.map((q) => (
            <button
              key={q}
              onClick={() => send(q)}
              className="text-xs px-2.5 py-1 bg-blue-50 text-blue-700 rounded-full hover:bg-blue-100"
            >
              {q}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div className="p-3 border-t border-gray-100 flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && send(input)}
          placeholder="Digite sua pergunta…"
          className="flex-1 text-sm border border-gray-200 rounded-full px-3 py-2 focus:outline-none focus:border-blue-400"
        />
        <button
          onClick={() => send(input)}
          disabled={loading}
          className="w-9 h-9 bg-blue-600 text-white rounded-full flex items-center justify-center hover:bg-blue-700 disabled:opacity-50"
          aria-label="Enviar"
        >
          ➤
        </button>
      </div>
    </div>
  );
}

'use client';

import type { Child, MedicalRecord } from '@/types';

interface Props {
  child: Child;
  lastRecord?: MedicalRecord;
  timeline?: any[];
  examResults?: any[];
  closureRecord?: any;
  onRefresh: () => void;
}

/**
 * Seção "7. Evolução Clínica" do prontuário.
 * Estrutura pronta para ligação aos endpoints em prontuarioApi.
 */
export default function EvolucaoSection({ child, lastRecord }: Props) {
  return (
    <div className="max-w-3xl space-y-4">
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <h3 className="text-sm font-semibold text-gray-800">7. Evolução Clínica</h3>
        <p className="text-xs text-gray-400 mt-1">Linha do tempo de consultas, vacinas, exames e visitas.</p>
        <p className="text-sm text-gray-600 mt-4">Paciente: <strong>{child.fullName}</strong></p>
      </div>
    </div>
  );
}

'use client';

import type { Child, MedicalRecord } from '@/types';

interface Props {
  child: Child;
  lastRecord?: MedicalRecord;
  timeline?: any[];
  examResults?: any[];
  closureRecord?: any;
  onRefresh: () => void;
}

/**
 * Seção "5. Diagnóstico Definitivo" do prontuário.
 * Estrutura pronta para ligação aos endpoints em prontuarioApi.
 */
export default function DiagnosticoSection({ child, lastRecord }: Props) {
  return (
    <div className="max-w-3xl space-y-4">
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <h3 className="text-sm font-semibold text-gray-800">5. Diagnóstico Definitivo</h3>
        <p className="text-xs text-gray-400 mt-1">Diagnóstico confirmado e secundários.</p>
        <p className="text-sm text-gray-600 mt-4">Paciente: <strong>{child.fullName}</strong></p>
      </div>
    </div>
  );
}

'use client';

import { useState } from 'react';
import { prontuarioApi } from '@/lib/api';
import type { Prescription, MedicalRecord, Child } from '@/types';

interface Props {
  child: Child;
  lastRecord?: MedicalRecord;
  onRefresh: () => void;
}

const ROUTES = [
  { value: 'VO', label: 'Via oral (VO)' },
  { value: 'IV', label: 'Intravenoso (IV)' },
  { value: 'IM', label: 'Intramuscular (IM)' },
  { value: 'SC', label: 'Subcutâneo (SC)' },
  { value: 'INAL', label: 'Inalatório (INAL)' },
  { value: 'TOPIC', label: 'Tópico' },
];

const empty = {
  medicationName: '', dosage: '', route: 'VO', frequency: '',
  duration: '', instructions: '', isControlled: false, contraindicated: '',
};

export default function PrescricaoSection({ child, lastRecord, onRefresh }: Props) {
  const [form, setForm] = useState({ ...empty });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const prescriptions: Prescription[] = lastRecord?.prescriptions ?? [];
  const allergies = child.allergies ?? '';

  const hasAllergyWarning =
    allergies && form.medicationName &&
    allergies.toLowerCase().includes(form.medicationName.toLowerCase().slice(0, 5));

  async function save() {
    if (!form.medicationName || !form.dosage || !form.frequency) return;
    setSaving(true);
    try {
      await prontuarioApi.createRecord(child.id, {
        appointmentDate: lastRecord?.appointmentDate ?? new Date().toISOString(),
        prescriptions: [form],
      });
      setSaved(true);
      setForm({ ...empty });
      onRefresh();
      setTimeout(() => setSaved(false), 2000);
    } finally {
      setSaving(false);
    }
  }

  const field = (k: keyof typeof form, v: any) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <div className="space-y-6 max-w-3xl">
      {prescriptions.length > 0 && (
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="text-sm font-semibold text-gray-800 mb-4">💊 Prescrições desta consulta</h3>
          <div className="space-y-3">
            {prescriptions.map((p, i) => (
              <div key={p.id} className="flex items-start justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-gray-800">
                    {i + 1}. {p.medicationName}
                    {p.isControlled && <span className="ml-2 text-xs px-1.5 py-0.5 bg-red-100 text-red-700 rounded">Controlado</span>}
                  </p>
                  <p className="text-xs text-gray-500 mt-0.5">
                    {p.dosage} · {p.frequency} · {p.route}{p.duration && ` · ${p.duration}`}
                  </p>
                  {p.instructions && <p className="text-xs text-gray-400 mt-0.5 italic">{p.instructions}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {allergies && (
        <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg text-xs text-orange-800">
          ⚠ <strong>Alergias documentadas:</strong> {allergies}
          {hasAllergyWarning && <span className="ml-2 font-bold text-red-700">— ATENÇÃO: possível contraindicação!</span>}
        </div>
      )}

      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <h3 className="text-sm font-semibold text-gray-800 mb-4">+ Adicionar medicamento</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <label className="text-xs text-gray-500 mb-1 block">Medicamento *</label>
            <input value={form.medicationName} onChange={(e) => field('medicationName', e.target.value)}
              placeholder="Ex: Amoxicilina 250mg/5mL"
              className={`w-full text-sm border rounded-lg px-3 py-2 ${hasAllergyWarning ? 'border-red-300 bg-red-50' : 'border-gray-200'}`} />
          </div>
          <div>
            <label className="text-xs text-gray-500 mb-1 block">Dose / Posologia *</label>
            <input value={form.dosage} onChange={(e) => field('dosage', e.target.value)}
              placeholder="Ex: 10mg/kg" className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2" />
          </div>
          <div>
            <label className="text-xs text-gray-500 mb-1 block">Via *</label>
            <select value={form.route} onChange={(e) => field('route', e.target.value)}
              className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2">
              {ROUTES.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-gray-500 mb-1 block">Frequência *</label>
            <input value={form.frequency} onChange={(e) => field('frequency', e.target.value)}
              placeholder="Ex: a cada 8h" className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2" />
          </div>
          <div>
            <label className="text-xs text-gray-500 mb-1 block">Duração</label>
            <input value={form.duration} onChange={(e) => field('duration', e.target.value)}
              placeholder="Ex: 7 dias" className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2" />
          </div>
          <div className="col-span-2">
            <label className="text-xs text-gray-500 mb-1 block">Instruções</label>
            <textarea value={form.instructions} onChange={(e) => field('instructions', e.target.value)} rows={2}
              placeholder="Ex: Usar com espaçador. Tomar com alimento."
              className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 resize-none" />
          </div>
          <div className="flex items-center gap-2">
            <input type="checkbox" id="ctrl" checked={form.isControlled}
              onChange={(e) => field('isControlled', e.target.checked)} className="w-4 h-4" />
            <label htmlFor="ctrl" className="text-sm text-gray-600">Medicamento controlado</label>
          </div>
        </div>
        <div className="mt-4 flex gap-3">
          <button onClick={save} disabled={saving || !form.medicationName}
            className="px-5 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 disabled:opacity-50">
            {saving ? 'Salvando…' : saved ? '✓ Salvo!' : 'Adicionar'}
          </button>
          <button onClick={() => setForm({ ...empty })}
            className="px-4 py-2 text-sm border border-gray-200 rounded-lg hover:bg-gray-50">Limpar</button>
        </div>
      </div>
    </div>
  );
}

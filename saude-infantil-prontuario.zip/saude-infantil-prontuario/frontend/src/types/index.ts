export type Role = 'SUPER_ADMIN' | 'ADMIN' | 'GESTOR' | 'AGENTE' | 'DIGITADOR' | 'MEDICO' | 'ENFERMEIRO';
export type RecordStatus = 'ATIVO' | 'ALTA' | 'TRANSFERIDO' | 'OBITO';
export type AlertSeverity = 'BAIXA' | 'MEDIA' | 'ALTA' | 'CRITICA';
export type RouteType = 'VO' | 'IV' | 'IM' | 'SC' | 'INAL' | 'TOPIC';

export interface Child {
  id: string;
  municipalityId: string;
  fullName: string;
  birthDate: string;
  gender: string;
  cpf?: string;
  susCard?: string;
  motherName: string;
  guardianName?: string;
  phone?: string;
  address: string;
  number?: string;
  neighborhood: string;
  city: string;
  allergies?: string;
  chronicDiseases?: string;
  status: RecordStatus;
  isActive: boolean;
  alerts?: Alert[];
  medicalRecords?: MedicalRecord[];
  examResults?: ExamResult[];
  closureRecord?: ClosureRecord;
}

export interface Anamnese {
  id: string;
  mainComplaint: string;
  symptomDuration?: string;
  previousDiseases?: string;
  knownAllergies?: string;
  familyHistory?: string;
}

export interface PhysicalExam {
  id: string;
  temperature?: number;
  heartRate?: number;
  respiratoryRate?: number;
  oxygenSat?: number;
  weight?: number;
  height?: number;
  imc?: number;
  nutritionalStatus?: string;
  respiratory?: string;
  cardiovascular?: string;
  abdomen?: string;
}

export interface DiagnosticHypothesis {
  id: string;
  description: string;
  cidCode?: string;
  probability: 'ALTA' | 'MEDIA' | 'BAIXA';
  order: number;
}

export interface Prescription {
  id: string;
  medicationName: string;
  dosage: string;
  route: RouteType;
  frequency: string;
  duration?: string;
  instructions?: string;
  isControlled: boolean;
  contraindicated?: string;
}

export interface MedicalRecord {
  id: string;
  childId: string;
  doctor?: { id: string; name: string; role: Role };
  appointmentDate: string;
  appointmentType: string;
  definiteDiagnosis?: string;
  definiteDiagCid?: string;
  treatmentPlan?: string;
  clinicalEvolution?: string;
  patientResponse?: string;
  anamnese?: Anamnese;
  physicalExam?: PhysicalExam;
  diagnosticHypotheses?: DiagnosticHypothesis[];
  prescriptions?: Prescription[];
}

export interface ExamResult {
  id: string;
  examType: string;
  examName: string;
  requestDate: string;
  resultDate?: string;
  result?: string;
  unit?: string;
  interpretation?: 'NORMAL' | 'ALTERADO' | 'CRITICO';
}

export interface ClosureRecord {
  id: string;
  closureType: 'ALTA' | 'TRANSFERENCIA' | 'OBITO';
  closureDate: string;
  dischargeSummary?: string;
  transferDestination?: string;
  deathCause?: string;
}

export interface Alert {
  id: string;
  type: string;
  severity: AlertSeverity;
  message: string;
  resolved: boolean;
}

export interface Appointment {
  id: string;
  type: string;
  specialty?: string;
  scheduledAt: string;
  estimatedTime?: string;
  status: string;
  professional?: { name: string; specialty?: string };
  healthUnit?: { name: string; address?: string };
}

export interface Referral {
  id: string;
  specialty: string;
  priority: string;
  reason: string;
  status: string;
  scheduledAt?: string;
}

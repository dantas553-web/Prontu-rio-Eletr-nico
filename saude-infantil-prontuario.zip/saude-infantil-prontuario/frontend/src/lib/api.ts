import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:3001';
const api = axios.create({ baseURL: API_URL });

api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401 && typeof window !== 'undefined') {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  },
);

export const authApi = {
  login: (email: string, password: string) =>
    api.post('/auth/login', { email, password }).then((r) => r.data),
  me: () => api.get('/auth/me').then((r) => r.data),
};

export const childrenApi = {
  list: (municipalityId: string) =>
    api.get(`/children?municipalityId=${municipalityId}`).then((r) => r.data),
  get: (id: string) => api.get(`/children/${id}`).then((r) => r.data),
  create: (data: any) => api.post('/children', data).then((r) => r.data),
  update: (id: string, data: any) => api.put(`/children/${id}`, data).then((r) => r.data),
  search: (q: string, municipalityId: string) =>
    api.get(`/children/search?q=${q}&municipalityId=${municipalityId}`).then((r) => r.data),
};

export const prontuarioApi = {
  getFull: (childId: string) => api.get(`/prontuario/${childId}`).then((r) => r.data),
  getTimeline: (childId: string) => api.get(`/prontuario/${childId}/timeline`).then((r) => r.data),
  createRecord: (childId: string, data: any) =>
    api.post(`/prontuario/${childId}/consulta`, data).then((r) => r.data),
  saveAnamnese: (recordId: string, data: any) =>
    api.post(`/prontuario/consulta/${recordId}/anamnese`, data).then((r) => r.data),
  savePhysicalExam: (recordId: string, data: any) =>
    api.post(`/prontuario/consulta/${recordId}/exame-fisico`, data).then((r) => r.data),
  addExamResult: (childId: string, data: any) =>
    api.post(`/prontuario/${childId}/exame`, data).then((r) => r.data),
  createClosure: (childId: string, data: any) =>
    api.post(`/prontuario/${childId}/encerramento`, data).then((r) => r.data),
};

export const schedulingApi = {
  byChild: (childId: string) => api.get(`/scheduling/child/${childId}`).then((r) => r.data),
  queue: (unitId: string) => api.get(`/scheduling/queue/${unitId}`).then((r) => r.data),
  schedule: (data: any) => api.post('/scheduling', data).then((r) => r.data),
  updateStatus: (id: string, status: string, estimatedTime?: string) =>
    api.patch(`/scheduling/${id}/status`, { status, estimatedTime }).then((r) => r.data),
};

export const referralsApi = {
  byChild: (childId: string) => api.get(`/referrals/child/${childId}`).then((r) => r.data),
  pending: (municipalityId: string) =>
    api.get(`/referrals/pending?municipalityId=${municipalityId}`).then((r) => r.data),
  create: (data: any) => api.post('/referrals', data).then((r) => r.data),
  regulate: (id: string, scheduledAt?: string) =>
    api.patch(`/referrals/${id}/regulate`, { scheduledAt }).then((r) => r.data),
};

export const bpaApi = {
  production: (competencia: string, cnes: string, municipalityId: string) =>
    api.get(`/bpa/producao?competencia=${competencia}&cnes=${cnes}&municipalityId=${municipalityId}`).then((r) => r.data),
  export: (body: any) =>
    api.post('/bpa/exportar', body, { responseType: 'blob' }).then((r) => {
      const url = URL.createObjectURL(new Blob([r.data]));
      const a = document.createElement('a');
      a.href = url; a.download = `BPA${body.competencia}.txt`; a.click();
      URL.revokeObjectURL(url);
    }),
};

export const dataQualityApi = {
  audit: (municipalityId: string) =>
    api.post(`/data-quality/audit?municipalityId=${municipalityId}`).then((r) => r.data),
  issues: (municipalityId: string) =>
    api.get(`/data-quality/issues?municipalityId=${municipalityId}`).then((r) => r.data),
};

export const monitoringApi = {
  health: (municipalityId: string) =>
    api.get(`/monitoring/health?municipalityId=${municipalityId}`).then((r) => r.data),
};

export const reportsApi = {
  prontuarioPdf: (childId: string) =>
    api.get(`/reports/prontuario/${childId}/pdf`, { responseType: 'blob' }).then((r) => {
      const url = URL.createObjectURL(new Blob([r.data], { type: 'application/pdf' }));
      const a = document.createElement('a');
      a.href = url; a.download = `prontuario-${childId}.pdf`; a.click();
      URL.revokeObjectURL(url);
    }),
  municipalExcel: (municipalityId: string) =>
    api.get(`/reports/municipal/${municipalityId}/excel`, { responseType: 'blob' }).then((r) => {
      const url = URL.createObjectURL(new Blob([r.data]));
      const a = document.createElement('a');
      a.href = url; a.download = 'relatorio-municipal.xlsx'; a.click();
      URL.revokeObjectURL(url);
    }),
};

export const aiApi = {
  predict: (data: any) => axios.post('http://localhost:8000/predict', data).then((r) => r.data),
};

export default api;

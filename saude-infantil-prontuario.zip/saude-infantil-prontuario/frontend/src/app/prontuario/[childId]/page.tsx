'use client';

import { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { prontuarioApi, reportsApi } from '@/lib/api';
import type { Child, MedicalRecord, Alert } from '@/types';

import IdentificacaoSection from '@/components/prontuario/IdentificacaoSection';
import AnamneseSection from '@/components/prontuario/AnamneseSection';
import ExameFisicoSection from '@/components/prontuario/ExameFisicoSection';
import HipotesesSection from '@/components/prontuario/HipotesesSection';
import DiagnosticoSection from '@/components/prontuario/DiagnosticoSection';
import PlanoSection from '@/components/prontuario/PlanoSection';
import EvolucaoSection from '@/components/prontuario/EvolucaoSection';
import PrescricaoSection from '@/components/prontuario/PrescricaoSection';
import ExamesSection from '@/components/prontuario/ExamesSection';
import EncerramentoSection from '@/components/prontuario/EncerramentoSection';
import AssistantChat from '@/components/assistant/AssistantChat';

const SECTIONS = [
  { id: 1, label: 'Identificação', icon: '👤' },
  { id: 2, label: 'Anamnese', icon: '💬' },
  { id: 3, label: 'Exame Físico', icon: '🩺' },
  { id: 4, label: 'Hipóteses', icon: '🧠' },
  { id: 5, label: 'Diagnóstico', icon: '✅' },
  { id: 6, label: 'Plano', icon: '🗓️' },
  { id: 7, label: 'Evolução', icon: '📈' },
  { id: 8, label: 'Prescrição', icon: '💊' },
  { id: 9, label: 'Exames', icon: '🔬' },
  { id: 10, label: 'Encerramento', icon: '🚪' },
];

export default function ProntuarioPage() {
  const params = useParams();
  const router = useRouter();
  const queryClient = useQueryClient();
  const childId = params.childId as string;
  const [active, setActive] = useState(1);

  const { data: prontuario, isLoading } = useQuery(
    ['prontuario', childId],
    () => prontuarioApi.getFull(childId),
    { enabled: !!childId },
  );
  const { data: timeline } = useQuery(
    ['timeline', childId],
    () => prontuarioApi.getTimeline(childId),
    { enabled: !!childId && active === 7 },
  );

  const createRecord = useMutation(
    () => prontuarioApi.createRecord(childId, { appointmentDate: new Date().toISOString() }),
    { onSuccess: () => queryClient.invalidateQueries(['prontuario', childId]) },
  );

  if (isLoading) return <Loading />;
  if (!prontuario) return <NotFound />;

  const child: Child = prontuario;
  const lastRecord: MedicalRecord | undefined = prontuario.medicalRecords?.[0];
  const refresh = () => queryClient.invalidateQueries(['prontuario', childId]);
  const props = {
    child, lastRecord, onRefresh: refresh,
    timeline: timeline?.timeline ?? [], examResults: prontuario.examResults ?? [],
    closureRecord: prontuario.closureRecord,
  };

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      <aside className="w-56 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-4 border-b border-gray-100">
          <h1 className="text-sm font-semibold text-gray-800">Prontuário</h1>
          <p className="text-xs text-gray-400 mt-0.5">Sistema Municipal</p>
        </div>

        <div className="mx-3 my-3 p-3 bg-blue-50 rounded-lg cursor-pointer" onClick={() => router.push(`/children/${childId}`)}>
          <p className="text-xs font-medium text-blue-900 truncate">{child.fullName}</p>
          <p className="text-xs text-blue-600 mt-0.5">{calcAge(child.birthDate)} anos · SUS: {child.susCard?.slice(-4) ?? '—'}</p>
        </div>

        {child.alerts && child.alerts.length > 0 && (
          <div className="mx-3 mb-2 space-y-1">
            {child.alerts.slice(0, 2).map((a: Alert) => (
              <div key={a.id} className={`px-2 py-1.5 rounded text-xs ${
                a.severity === 'CRITICA' ? 'bg-red-50 text-red-700' :
                a.severity === 'ALTA' ? 'bg-orange-50 text-orange-700' : 'bg-yellow-50 text-yellow-700'}`}>
                ⚠ {a.message.slice(0, 45)}…
              </div>
            ))}
          </div>
        )}

        <nav className="flex-1 overflow-y-auto py-2">
          {SECTIONS.map((s) => (
            <button key={s.id} onClick={() => setActive(s.id)}
              className={`w-full flex items-center gap-2.5 px-4 py-2.5 text-left transition-colors ${
                active === s.id ? 'bg-blue-50 text-blue-700 font-medium border-l-2 border-blue-600'
                : 'text-gray-500 hover:bg-gray-50'}`}>
              <span className="text-base">{s.icon}</span>
              <span className="text-xs">{s.id}. {s.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-3 border-t border-gray-100 space-y-2">
          <button onClick={() => reportsApi.prontuarioPdf(childId)}
            className="w-full text-xs py-2 px-3 border border-gray-200 rounded-lg hover:bg-gray-50 text-gray-600">📄 Exportar PDF</button>
          <button onClick={() => createRecord.mutate()}
            className="w-full text-xs py-2 px-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700">+ Nova Consulta</button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between">
          <div>
            <h2 className="text-base font-medium text-gray-900">
              {SECTIONS[active - 1].icon} {SECTIONS[active - 1].id}. {SECTIONS[active - 1].label}
            </h2>
            <p className="text-xs text-gray-400">
              {lastRecord ? `Última consulta: ${new Date(lastRecord.appointmentDate).toLocaleDateString('pt-BR')}` : 'Sem consultas'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className={`text-xs px-2 py-1 rounded-full ${
              child.status === 'ATIVO' ? 'bg-green-50 text-green-700' : 'bg-blue-50 text-blue-700'}`}>{child.status}</span>
            <button onClick={() => setActive((s) => Math.max(1, s - 1))} disabled={active === 1}
              className="text-xs px-3 py-1.5 border border-gray-200 rounded hover:bg-gray-50 disabled:opacity-30">← Anterior</button>
            <button onClick={() => setActive((s) => Math.min(10, s + 1))} disabled={active === 10}
              className="text-xs px-3 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-30">Próximo →</button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6">
          {active === 1 && <IdentificacaoSection {...props} />}
          {active === 2 && <AnamneseSection {...props} />}
          {active === 3 && <ExameFisicoSection {...props} />}
          {active === 4 && <HipotesesSection {...props} />}
          {active === 5 && <DiagnosticoSection {...props} />}
          {active === 6 && <PlanoSection {...props} />}
          {active === 7 && <EvolucaoSection {...props} />}
          {active === 8 && <PrescricaoSection {...props} />}
          {active === 9 && <ExamesSection {...props} />}
          {active === 10 && <EncerramentoSection {...props} />}
        </div>
      </main>

      <AssistantChat childId={childId} municipalityId={child.municipalityId} />
    </div>
  );
}

function calcAge(b: string) {
  return Math.floor((Date.now() - new Date(b).getTime()) / (365.25 * 86400000));
}
function Loading() {
  return <div className="flex items-center justify-center h-screen"><div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" /></div>;
}
function NotFound() {
  return <div className="flex items-center justify-center h-screen"><p className="text-gray-500">Paciente não encontrado.</p></div>;
}

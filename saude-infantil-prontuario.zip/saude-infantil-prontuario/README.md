# 🏥 Sistema Municipal de Saúde Infantil

Plataforma de gestão da saúde infantil com Prontuário Eletrônico de 10 pontos,
BPA/SIASUS, assistente virtual, qualificação de dados, IA preditiva e monitoramento.

---

## Stack

| Camada   | Tecnologia |
|----------|-----------|
| Backend  | NestJS + Prisma + PostgreSQL |
| Frontend | Next.js 15 + TailwindCSS |
| IA       | FastAPI + Scikit-Learn (GradientBoostingClassifier) |
| Infra    | Docker + Docker Compose |

---

## Prontuário Eletrônico — 10 Pontos

| # | Seção | Modelo |
|---|-------|--------|
| 1 | Identificação | `Child` |
| 2 | Anamnese | `Anamnese` |
| 3 | Exame físico | `PhysicalExam` |
| 4 | Hipóteses diagnósticas | `DiagnosticHypothesis` |
| 5 | Diagnóstico definitivo | `MedicalRecord` |
| 6 | Plano de tratamento | `MedicalRecord` |
| 7 | Evolução clínica | timeline |
| 8 | Prescrição médica | `Prescription` |
| 9 | Resultados de exames | `ExamResult` |
| 10 | Encerramento | `ClosureRecord` |

---

## Módulos por especificação

| Especificação | Módulo |
|---------------|--------|
| Cadastro de pacientes | `children` |
| Qualificação de dados | `data-quality` (valida CNS/CPF/CID-10, duplicatas, score) |
| Gestão de consultas/tratamentos | `prontuario` |
| Relatórios / BPA dinâmico | `bpa` + `reports` |
| Assistente virtual (FAQ, CNS, agendas) | `assistant` + `AssistantChat.tsx` |
| Acompanhamento de atendimentos | `scheduling` (status, fila do dia) |
| Consultas/exames agendados | `scheduling` (`Appointment`) |
| Atenção especializada/encaminhamentos | `referrals` |
| BPA-I e BPA-C (SIASUS) | `bpa.service` (arquivo magnético) |
| Equipe multiprofissional | `Professional` + `HealthUnit` |
| Monitoramento diário | `monitoring` (job de integridade) |
| LGPD / segurança | `docs/SEGURANCA_LGPD.md` |
| Backup / DR | `docs/BACKUP_DR.md` |

Ver `docs/COBERTURA_REQUISITOS.md` para o mapeamento completo das ~24 especificações.

---

## Início Rápido (Docker)

```bash
cp .env.example .env
docker-compose up --build
```

Frontend: http://localhost:3000 · Backend: http://localhost:3001 · IA: http://localhost:8000

---

## Desenvolvimento local

```bash
# Backend
cd backend && npm install
npx prisma migrate dev --name init
npm run start:dev

# Frontend
cd frontend && npm install && npm run dev

# IA (treinar modelo antes)
cd ai-service && pip install -r requirements.txt
cd training && python train.py && cd ..
uvicorn main:app --reload --port 8000
```

---

## BPA / SIASUS

O gerador (`bpa.service.ts`) produz o arquivo magnético com cabeçalho `01` + `#BPA#`,
linhas `02` (BPA-C consolidado) e `03` (BPA-I individualizado), competência `AAAAMM`,
SIGTAP (10 díg), CNES (7), CNS (15), CBO e CID-10, com campo de controle
`(Σ procedimentos) % 1111 + 1111`.

> ⚠️ **Antes de enviar em produção**, valide as larguras de cada campo e a string de
> versão contra o `Layout_Exportacao_BPA.pdf` da competência-alvo no Portal do SIA
> (sia.datasus.gov.br) — o layout é versionado pelo Ministério da Saúde.

---

## Requisitos não-funcionais

- **Responsividade / multiplataforma**: TailwindCSS mobile-first; pronto para PWA (iOS/Android).
- **Escalabilidade / performance**: serviços separados, índices Prisma, stateless JWT, pronto para Kubernetes.
- **Segurança / LGPD**: JWT + RBAC (7 perfis) + auditoria; MFA (TOTP) e criptografia AES-256-GCM documentados.
- **Backup / DR**: estratégia 3-2-1, PITR, RPO ≤ 5 min, RTO ≤ 1h.

---

## Licença

MIT

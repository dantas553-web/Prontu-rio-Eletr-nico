import { Controller, Get, Post, Body, Param, UseGuards, Request } from '@nestjs/common';
import { ProntuarioService } from './prontuario.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';

@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('prontuario')
export class ProntuarioController {
  constructor(private readonly prontuarioService: ProntuarioService) {}

  @Get(':childId')
  @Roles('MEDICO', 'ENFERMEIRO', 'ADMIN', 'GESTOR', 'SUPER_ADMIN')
  getFullRecord(@Param('childId') childId: string) {
    return this.prontuarioService.getFullRecord(childId);
  }

  @Get(':childId/timeline')
  @Roles('MEDICO', 'ENFERMEIRO', 'ADMIN', 'GESTOR', 'SUPER_ADMIN')
  getTimeline(@Param('childId') childId: string) {
    return this.prontuarioService.getClinicalTimeline(childId);
  }

  @Post(':childId/consulta')
  @Roles('MEDICO', 'ENFERMEIRO')
  createRecord(@Param('childId') childId: string, @Body() dto: any, @Request() req: any) {
    return this.prontuarioService.createMedicalRecord(childId, dto, req.user.sub);
  }

  @Post('consulta/:recordId/anamnese')
  @Roles('MEDICO', 'ENFERMEIRO')
  createAnamnese(@Param('recordId') recordId: string, @Body() dto: any) {
    return this.prontuarioService.createAnamnese(recordId, dto);
  }

  @Post('consulta/:recordId/exame-fisico')
  @Roles('MEDICO', 'ENFERMEIRO')
  createPhysicalExam(@Param('recordId') recordId: string, @Body() dto: any) {
    return this.prontuarioService.createPhysicalExam(recordId, dto);
  }

  @Post(':childId/exame')
  @Roles('MEDICO', 'ENFERMEIRO', 'DIGITADOR')
  addExamResult(@Param('childId') childId: string, @Body() dto: any) {
    return this.prontuarioService.addExamResult(childId, dto);
  }

  @Post(':childId/encerramento')
  @Roles('MEDICO', 'ADMIN')
  createClosure(@Param('childId') childId: string, @Body() dto: any) {
    return this.prontuarioService.createClosureRecord(childId, dto);
  }
}

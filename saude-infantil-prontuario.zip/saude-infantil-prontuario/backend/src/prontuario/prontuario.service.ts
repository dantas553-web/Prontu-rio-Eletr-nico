import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { AlertsService } from '../alerts/alerts.service';

@Injectable()
export class ProntuarioService {
  constructor(private prisma: PrismaService, private alertsService: AlertsService) {}

  // Prontuário completo (todos os 10 pontos)
  async getFullRecord(childId: string) {
    const child = await this.prisma.child.findUnique({
      where: { id: childId },
      include: {
        medicalRecords: {
          include: {
            anamnese: true, physicalExam: true,
            diagnosticHypotheses: { orderBy: { order: 'asc' } },
            prescriptions: true, examResults: true,
            doctor: { select: { id: true, name: true, role: true } },
          },
          orderBy: { appointmentDate: 'desc' },
        },
        vaccines: { orderBy: { appliedAt: 'desc' } },
        growthRecords: { orderBy: { createdAt: 'desc' } },
        examResults: { orderBy: { requestDate: 'desc' } },
        alerts: { where: { resolved: false }, orderBy: { createdAt: 'desc' } },
        closureRecord: true,
      },
    });
    if (!child) throw new NotFoundException(`Paciente ${childId} não encontrado`);
    return child;
  }

  // Nova consulta (Pontos 4-8)
  async createMedicalRecord(childId: string, dto: any, doctorId: string) {
    const child = await this.prisma.child.findUnique({ where: { id: childId } });
    if (!child) throw new NotFoundException('Paciente não encontrado');

    const record = await this.prisma.medicalRecord.create({
      data: {
        childId, doctorId,
        appointmentDate: dto.appointmentDate, appointmentType: dto.appointmentType ?? 'CONSULTA',
        definiteDiagnosis: dto.definiteDiagnosis, definiteDiagCid: dto.definiteDiagCid,
        secondaryDiagnoses: dto.secondaryDiagnoses, treatmentPlan: dto.treatmentPlan,
        therapies: dto.therapies, referrals: dto.referrals, nextAppointment: dto.nextAppointment,
        clinicalEvolution: dto.clinicalEvolution, patientResponse: dto.patientResponse,
        complications: dto.complications, notes: dto.notes,
        diagnosticHypotheses: dto.hypotheses ? {
          create: dto.hypotheses.map((h: any, i: number) => ({
            description: h.description, cidCode: h.cidCode, probability: h.probability, order: i + 1,
          })),
        } : undefined,
        prescriptions: dto.prescriptions ? {
          create: dto.prescriptions.map((p: any) => ({
            medicationName: p.medicationName, dosage: p.dosage, route: p.route,
            frequency: p.frequency, duration: p.duration, instructions: p.instructions,
            isControlled: p.isControlled ?? false, contraindicated: p.contraindicated,
          })),
        } : undefined,
      },
      include: { diagnosticHypotheses: true, prescriptions: true },
    });

    await this.alertsService.generateAlerts(childId);
    return record;
  }

  // Ponto 2: Anamnese
  async createAnamnese(medicalRecordId: string, dto: any) {
    const record = await this.prisma.medicalRecord.findUnique({ where: { id: medicalRecordId } });
    if (!record) throw new NotFoundException('Prontuário não encontrado');
    return this.prisma.anamnese.upsert({
      where: { medicalRecordId },
      create: { medicalRecordId, ...dto }, update: { ...dto },
    });
  }

  // Ponto 3: Exame físico
  async createPhysicalExam(medicalRecordId: string, dto: any) {
    const imc = dto.weight && dto.height
      ? parseFloat((dto.weight / (dto.height / 100) ** 2).toFixed(1)) : undefined;
    const nutritionalStatus = imc ? this.calcNutritionalStatus(imc) : dto.nutritionalStatus;

    const exam = await this.prisma.physicalExam.upsert({
      where: { medicalRecordId },
      create: { medicalRecordId, ...dto, imc, nutritionalStatus },
      update: { ...dto, imc, nutritionalStatus },
    });

    if (dto.weight && dto.height) {
      const record = await this.prisma.medicalRecord.findUnique({
        where: { id: medicalRecordId }, select: { childId: true },
      });
      if (record) {
        await this.prisma.growthRecord.create({
          data: { childId: record.childId, weight: dto.weight, height: dto.height, imc: imc!, nutritionalStatus },
        });
      }
    }
    return exam;
  }

  // Ponto 9: Resultados de exames
  async addExamResult(childId: string, dto: any) {
    const result = await this.prisma.examResult.create({ data: { childId, ...dto } });
    if (dto.interpretation === 'CRITICO') {
      await this.prisma.alert.create({
        data: {
          childId, type: 'EXAME_CRITICO', severity: 'CRITICA',
          message: `Resultado crítico: ${dto.examName} — ${dto.result} ${dto.unit ?? ''}`,
        },
      });
    }
    return result;
  }

  // Ponto 10: Encerramento
  async createClosureRecord(childId: string, dto: any) {
    const closure = await this.prisma.closureRecord.upsert({
      where: { childId }, create: { childId, ...dto }, update: { ...dto },
    });
    await this.prisma.child.update({
      where: { id: childId },
      data: { status: dto.closureType, isActive: dto.closureType === 'ALTA' },
    });
    return closure;
  }

  // Ponto 7: Evolução — timeline cronológica
  async getClinicalTimeline(childId: string) {
    const [records, vaccines, followUps, growth, exams] = await Promise.all([
      this.prisma.medicalRecord.findMany({
        where: { childId },
        include: {
          anamnese: { select: { mainComplaint: true } },
          physicalExam: { select: { temperature: true, oxygenSat: true, weight: true, height: true } },
          diagnosticHypotheses: true, prescriptions: true, doctor: { select: { name: true } },
        },
        orderBy: { appointmentDate: 'desc' },
      }),
      this.prisma.vaccine.findMany({ where: { childId }, orderBy: { appliedAt: 'desc' } }),
      this.prisma.followUp.findMany({ where: { childId }, orderBy: { createdAt: 'desc' } }),
      this.prisma.growthRecord.findMany({ where: { childId }, orderBy: { createdAt: 'desc' }, take: 10 }),
      this.prisma.examResult.findMany({ where: { childId, resultDate: { not: null } }, orderBy: { resultDate: 'desc' }, take: 20 }),
    ]);

    const timeline = [
      ...records.map((r) => ({ type: 'CONSULTA', date: r.appointmentDate, data: r })),
      ...vaccines.map((v) => ({ type: 'VACINA', date: v.appliedAt, data: v })),
      ...followUps.map((f) => ({ type: 'VISITA', date: f.createdAt, data: f })),
      ...exams.filter((e) => e.resultDate).map((e) => ({ type: 'EXAME', date: e.resultDate!, data: e })),
    ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    return { timeline, growthHistory: growth };
  }

  private calcNutritionalStatus(imc: number): string {
    if (imc < 13) return 'Magreza severa';
    if (imc < 14.5) return 'Magreza grau I';
    if (imc < 17) return 'Magreza grau II';
    if (imc < 25) return 'Eutrófico';
    if (imc < 30) return 'Sobrepeso';
    if (imc < 35) return 'Obesidade grau I';
    return 'Obesidade grau II+';
  }
}

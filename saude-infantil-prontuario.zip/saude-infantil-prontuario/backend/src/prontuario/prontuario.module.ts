import { Module } from '@nestjs/common';
import { ProntuarioController } from './prontuario.controller';
import { ProntuarioService } from './prontuario.service';
import { AlertsModule } from '../alerts/alerts.module';
import { PrismaService } from '../common/prisma.service';

@Module({
  imports: [AlertsModule],
  controllers: [ProntuarioController],
  providers: [ProntuarioService, PrismaService],
  exports: [ProntuarioService],
})
export class ProntuarioModule {}

import { Module } from '@nestjs/common';
import { ChildrenController } from './children.controller';
import { ChildrenService } from './children.service';
import { PrismaService } from '../common/prisma.service';

@Module({
  controllers: [ChildrenController],
  providers: [ChildrenService, PrismaService],
})
export class ChildrenModule {}

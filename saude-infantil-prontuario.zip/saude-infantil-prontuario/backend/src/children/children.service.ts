import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { DataQualityService } from '../data-quality/data-quality.service';

@Injectable()
export class ChildrenService {
  constructor(private prisma: PrismaService) {}

  async findAll(municipalityId: string) {
    return this.prisma.child.findMany({
      where: { municipalityId, isActive: true },
      include: { vaccines: true, growthRecords: { take: 1, orderBy: { createdAt: 'desc' } },
        alerts: { where: { resolved: false } } },
      orderBy: { fullName: 'asc' },
    });
  }

  async findOne(id: string) {
    const child = await this.prisma.child.findUnique({ where: { id } });
    if (!child) throw new NotFoundException('Paciente não encontrado');
    return child;
  }

  async search(q: string, municipalityId: string) {
    return this.prisma.child.findMany({
      where: {
        municipalityId,
        OR: [
          { fullName: { contains: q, mode: 'insensitive' } },
          { susCard: { contains: q } },
          { cpf: { contains: q } },
          { motherName: { contains: q, mode: 'insensitive' } },
        ],
      },
      take: 20,
    });
  }

  async create(data: any) {
    // Normaliza/valida antes de gravar (qualificação de dados)
    const clean = {
      ...data,
      fullName: DataQualityService.normalizeName(data.fullName),
      motherName: DataQualityService.normalizeName(data.motherName),
      phone: DataQualityService.normalizePhone(data.phone),
    };
    return this.prisma.child.create({ data: clean });
  }

  async update(id: string, data: any) {
    return this.prisma.child.update({ where: { id }, data });
  }
}

import { Controller, Get, Post, Put, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ChildrenService } from './children.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('children')
export class ChildrenController {
  constructor(private readonly childrenService: ChildrenService) {}

  @Get()
  findAll(@Query('municipalityId') municipalityId: string) {
    return this.childrenService.findAll(municipalityId);
  }

  @Get('search')
  search(@Query('q') q: string, @Query('municipalityId') municipalityId: string) {
    return this.childrenService.search(q, municipalityId);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.childrenService.findOne(id);
  }

  @Post()
  create(@Body() data: any) {
    return this.childrenService.create(data);
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() data: any) {
    return this.childrenService.update(id, data);
  }
}

import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';

/**
 * Serviço de qualificação de dados.
 * Limpa, valida e detecta inconsistências em dados clínicos para
 * garantir indicadores de saúde precisos e produção BPA sem glosa.
 */
@Injectable()
export class DataQualityService {
  constructor(private prisma: PrismaService) {}

  // ── Validadores de campo ─────────────────────────────
  static validateCNS(cns?: string): boolean {
    if (!cns) return false;
    const clean = cns.replace(/\D/g, '');
    if (clean.length !== 15) return false;
    // CNS provisório (inicia 7,8,9) e definitivo (1,2) têm regras de dígito.
    let sum = 0;
    for (let i = 0; i < 15; i++) sum += Number(clean[i]) * (15 - i);
    return sum % 11 === 0;
  }

  static validateCPF(cpf?: string): boolean {
    if (!cpf) return false;
    const c = cpf.replace(/\D/g, '');
    if (c.length !== 11 || /^(\d)\1{10}$/.test(c)) return false;
    const digit = (slice: string, factor: number) => {
      let total = 0;
      for (const n of slice) total += Number(n) * factor--;
      const rest = (total * 10) % 11;
      return rest === 10 ? 0 : rest;
    };
    return digit(c.slice(0, 9), 10) === Number(c[9]) && digit(c.slice(0, 10), 11) === Number(c[10]);
  }

  static validateCID10(cid?: string): boolean {
    if (!cid) return true; // opcional em vários contextos
    return /^[A-Z]\d{2}(\.\d)?$/.test(cid.toUpperCase());
  }

  static normalizeName(name: string): string {
    return name.trim().replace(/\s+/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase());
  }

  static normalizePhone(phone?: string): string | null {
    if (!phone) return null;
    const d = phone.replace(/\D/g, '');
    if (d.length < 10 || d.length > 11) return null;
    return d.length === 11
      ? `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`
      : `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  }

  // ── Auditoria completa de um município ───────────────
  async auditMunicipality(municipalityId: string) {
    const children = await this.prisma.child.findMany({
      where: { municipalityId },
      include: { growthRecords: { take: 1, orderBy: { createdAt: 'desc' } } },
    });

    const issues: Array<{
      entity: string; entityId: string; field: string;
      issueType: string; severity: string; description: string;
    }> = [];

    // Detectar duplicatas por CNS/CPF
    const cnsMap = new Map<string, string[]>();
    const cpfMap = new Map<string, string[]>();

    for (const c of children) {
      // CNS / Cartão SUS
      if (!c.susCard) {
        issues.push(issue(c.id, 'susCard', 'FALTANTE', 'ALTA', 'Paciente sem Cartão Nacional SUS (CNS).'));
      } else if (!DataQualityService.validateCNS(c.susCard)) {
        issues.push(issue(c.id, 'susCard', 'INVALIDO', 'ALTA', `CNS inválido: ${c.susCard}`));
      } else {
        cnsMap.set(c.susCard, [...(cnsMap.get(c.susCard) ?? []), c.id]);
      }

      // CPF
      if (c.cpf && !DataQualityService.validateCPF(c.cpf)) {
        issues.push(issue(c.id, 'cpf', 'INVALIDO', 'MEDIA', `CPF inválido: ${c.cpf}`));
      }
      if (c.cpf) cpfMap.set(c.cpf, [...(cpfMap.get(c.cpf) ?? []), c.id]);

      // Campos obrigatórios
      if (!c.motherName) issues.push(issue(c.id, 'motherName', 'FALTANTE', 'MEDIA', 'Nome da mãe ausente.'));
      if (!c.birthDate) issues.push(issue(c.id, 'birthDate', 'FALTANTE', 'ALTA', 'Data de nascimento ausente.'));
      if (!c.address || !c.neighborhood) {
        issues.push(issue(c.id, 'address', 'FALTANTE', 'BAIXA', 'Endereço incompleto.'));
      }
      if (c.phone && !DataQualityService.normalizePhone(c.phone)) {
        issues.push(issue(c.id, 'phone', 'INVALIDO', 'BAIXA', `Telefone fora do padrão: ${c.phone}`));
      }

      // Consistência clínica
      const g = c.growthRecords[0];
      if (g) {
        if (g.weight <= 0 || g.weight > 80) {
          issues.push(issue(c.id, 'weight', 'INCONSISTENTE', 'ALTA', `Peso fora da faixa pediátrica: ${g.weight}kg`));
        }
        if (g.height <= 0 || g.height > 180) {
          issues.push(issue(c.id, 'height', 'INCONSISTENTE', 'ALTA', `Altura fora da faixa pediátrica: ${g.height}cm`));
        }
      }
    }

    // Duplicatas
    for (const [cns, ids] of cnsMap) {
      if (ids.length > 1) {
        ids.forEach((id) =>
          issues.push(issue(id, 'susCard', 'DUPLICADO', 'ALTA', `CNS ${cns} usado por ${ids.length} pacientes.`)),
        );
      }
    }
    for (const [cpf, ids] of cpfMap) {
      if (ids.length > 1) {
        ids.forEach((id) =>
          issues.push(issue(id, 'cpf', 'DUPLICADO', 'ALTA', `CPF ${cpf} usado por ${ids.length} pacientes.`)),
        );
      }
    }

    // Persistir issues novas
    await this.prisma.dataQualityIssue.deleteMany({
      where: { resolved: false, entity: 'Child' },
    });
    if (issues.length > 0) {
      await this.prisma.dataQualityIssue.createMany({
        data: issues.map((i) => ({ ...i, entity: 'Child' })),
      });
    }

    return {
      totalChildren: children.length,
      totalIssues: issues.length,
      bySeverity: {
        ALTA: issues.filter((i) => i.severity === 'ALTA').length,
        MEDIA: issues.filter((i) => i.severity === 'MEDIA').length,
        BAIXA: issues.filter((i) => i.severity === 'BAIXA').length,
      },
      byType: {
        FALTANTE: issues.filter((i) => i.issueType === 'FALTANTE').length,
        INVALIDO: issues.filter((i) => i.issueType === 'INVALIDO').length,
        DUPLICADO: issues.filter((i) => i.issueType === 'DUPLICADO').length,
        INCONSISTENTE: issues.filter((i) => i.issueType === 'INCONSISTENTE').length,
      },
      qualityScore: Math.max(0, Math.round(100 - (issues.length / Math.max(children.length, 1)) * 20)),
      issues: issues.slice(0, 100),
    };
  }

  async getOpenIssues(municipalityId: string) {
    return this.prisma.dataQualityIssue.findMany({
      where: { resolved: false },
      orderBy: [{ severity: 'desc' }, { createdAt: 'desc' }],
      take: 200,
    });
  }
}

function issue(entityId: string, field: string, issueType: string, severity: string, description: string) {
  return { entityId, field, issueType, severity, description };
}

import { Controller, Get, Post, Query, UseGuards } from '@nestjs/common';
import { DataQualityService } from './data-quality.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';

@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('data-quality')
export class DataQualityController {
  constructor(private readonly dq: DataQualityService) {}

  @Post('audit')
  @Roles('GESTOR', 'ADMIN', 'SUPER_ADMIN')
  audit(@Query('municipalityId') municipalityId: string) {
    return this.dq.auditMunicipality(municipalityId);
  }

  @Get('issues')
  @Roles('GESTOR', 'ADMIN', 'SUPER_ADMIN')
  issues(@Query('municipalityId') municipalityId: string) {
    return this.dq.getOpenIssues(municipalityId);
  }
}

import { Module } from '@nestjs/common';
import { ReportsController } from './reports.controller';
import { ReportsService } from './reports.service';
import { ProntuarioModule } from '../prontuario/prontuario.module';
import { PrismaService } from '../common/prisma.service';

@Module({
  imports: [ProntuarioModule],
  controllers: [ReportsController],
  providers: [ReportsService, PrismaService],
})
export class ReportsModule {}

import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { ProntuarioService } from '../prontuario/prontuario.service';
import PDFDocument from 'pdfkit';
import * as ExcelJS from 'exceljs';
import * as QRCode from 'qrcode';

@Injectable()
export class ReportsService {
  constructor(private prisma: PrismaService, private prontuarioService: ProntuarioService) {}

  // Prontuário completo em PDF (com QR Code) + ficha de atendimento
  async generateProntuarioPdf(childId: string): Promise<Buffer> {
    const data = await this.prontuarioService.getFullRecord(childId);

    return new Promise(async (resolve, reject) => {
      const doc = new PDFDocument({ size: 'A4', margin: 50 });
      const chunks: Buffer[] = [];
      doc.on('data', (c) => chunks.push(c));
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);

      doc.fontSize(18).font('Helvetica-Bold').text('PRONTUÁRIO ELETRÔNICO', { align: 'center' });
      doc.fontSize(11).font('Helvetica').text('Sistema Municipal de Saúde', { align: 'center' });
      doc.moveDown();

      const qrDataUrl = await QRCode.toDataURL(`prontuario://${childId}`);
      doc.image(Buffer.from(qrDataUrl.split(',')[1], 'base64'), 470, 50, { width: 70 });
      doc.moveTo(50, doc.y).lineTo(545, doc.y).stroke();
      doc.moveDown(0.5);

      this.h(doc, '1. IDENTIFICAÇÃO DO PACIENTE');
      this.f(doc, 'Nome', data.fullName);
      this.f(doc, 'Nascimento', new Date(data.birthDate).toLocaleDateString('pt-BR'));
      this.f(doc, 'Sexo', data.gender);
      this.f(doc, 'CNS', data.susCard ?? '—');
      this.f(doc, 'Mãe', data.motherName);
      this.f(doc, 'Endereço', `${data.address}, ${data.number ?? 's/n'} — ${data.neighborhood}`);
      doc.moveDown(0.5);

      const lr = data.medicalRecords?.[0];
      if (lr?.anamnese) {
        this.h(doc, '2. ANAMNESE');
        this.f(doc, 'Queixa principal', lr.anamnese.mainComplaint);
        if (lr.anamnese.knownAllergies) this.f(doc, 'Alergias', lr.anamnese.knownAllergies);
        doc.moveDown(0.5);
      }
      if (lr?.physicalExam) {
        const pe = lr.physicalExam;
        this.h(doc, '3. EXAME FÍSICO');
        this.f(doc, 'Sinais vitais', [
          pe.temperature && `Temp ${pe.temperature}°C`, pe.heartRate && `FC ${pe.heartRate}`,
          pe.oxygenSat && `SpO₂ ${pe.oxygenSat}%`, pe.imc && `IMC ${pe.imc}`,
        ].filter(Boolean).join(' | '));
        if (pe.nutritionalStatus) this.f(doc, 'Estado nutricional', pe.nutritionalStatus);
        doc.moveDown(0.5);
      }
      if (lr?.diagnosticHypotheses?.length) {
        this.h(doc, '4. HIPÓTESES DIAGNÓSTICAS');
        lr.diagnosticHypotheses.forEach((hy: any, i: number) =>
          doc.fontSize(10).font('Helvetica').text(`${i + 1}. ${hy.description}${hy.cidCode ? ` (${hy.cidCode})` : ''} — ${hy.probability}`));
        doc.moveDown(0.5);
      }
      if (lr?.definiteDiagnosis) {
        this.h(doc, '5. DIAGNÓSTICO DEFINITIVO');
        this.f(doc, 'Diagnóstico', lr.definiteDiagnosis);
        if (lr.definiteDiagCid) this.f(doc, 'CID-10', lr.definiteDiagCid);
        doc.moveDown(0.5);
      }
      if (lr?.treatmentPlan) { this.h(doc, '6. PLANO DE TRATAMENTO'); this.f(doc, 'Plano', lr.treatmentPlan); doc.moveDown(0.5); }
      if (lr?.clinicalEvolution) { this.h(doc, '7. EVOLUÇÃO CLÍNICA'); this.f(doc, 'Evolução', lr.clinicalEvolution); doc.moveDown(0.5); }
      if (lr?.prescriptions?.length) {
        this.h(doc, '8. PRESCRIÇÃO MÉDICA');
        lr.prescriptions.forEach((p: any, i: number) => {
          doc.fontSize(10).font('Helvetica-Bold').text(`${i + 1}. ${p.medicationName}`);
          doc.font('Helvetica').text(`   ${p.dosage} — ${p.frequency} — ${p.route}${p.duration ? ` — ${p.duration}` : ''}`);
        });
        doc.moveDown(0.5);
      }
      if (data.examResults?.length) {
        this.h(doc, '9. RESULTADOS DE EXAMES');
        data.examResults.slice(0, 10).forEach((e: any) =>
          doc.fontSize(9).font('Helvetica').text(`${e.examName}: ${e.result ?? '—'} ${e.unit ?? ''} — ${e.interpretation ?? ''}`));
        doc.moveDown(0.5);
      }
      if (data.closureRecord) {
        this.h(doc, '10. ENCERRAMENTO');
        this.f(doc, 'Tipo', data.closureRecord.closureType);
        this.f(doc, 'Data', new Date(data.closureRecord.closureDate).toLocaleDateString('pt-BR'));
      }

      doc.moveDown();
      doc.fontSize(9).font('Helvetica').fillColor('gray')
        .text(`Emitido em ${new Date().toLocaleString('pt-BR')}`, { align: 'center' });
      doc.end();
    });
  }

  // Relatório Excel municipal com indicadores
  async generateMunicipalReport(municipalityId: string): Promise<Buffer> {
    const children = await this.prisma.child.findMany({
      where: { municipalityId, isActive: true },
      include: {
        growthRecords: { orderBy: { createdAt: 'desc' }, take: 1 },
        alerts: { where: { resolved: false } },
        medicalRecords: { orderBy: { appointmentDate: 'desc' }, take: 1 },
      },
    });

    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet('Pacientes');
    ws.columns = [
      { header: 'Nome', key: 'name', width: 30 }, { header: 'Idade', key: 'age', width: 8 },
      { header: 'Bairro', key: 'nb', width: 20 }, { header: 'IMC', key: 'imc', width: 8 },
      { header: 'Estado Nutric.', key: 'nut', width: 18 }, { header: 'Alertas', key: 'al', width: 10 },
      { header: 'Última Consulta', key: 'lc', width: 16 },
    ];
    ws.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
    ws.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF185FA5' } };

    children.forEach((c) => {
      const g = c.growthRecords[0]; const lc = c.medicalRecords[0];
      const age = Math.floor((Date.now() - new Date(c.birthDate).getTime()) / (365.25 * 86400000));
      const row = ws.addRow({
        name: c.fullName, age, nb: c.neighborhood, imc: g?.imc ?? '—',
        nut: g?.nutritionalStatus ?? '—', al: c.alerts.length,
        lc: lc ? new Date(lc.appointmentDate).toLocaleDateString('pt-BR') : 'Sem consulta',
      });
      if (c.alerts.some((a) => a.severity === 'CRITICA'))
        row.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFCEBEB' } };
    });

    const ws2 = wb.addWorksheet('Indicadores');
    const under = children.filter((c) => c.growthRecords[0]?.imc < 14.5).length;
    const over = children.filter((c) => c.growthRecords[0]?.imc >= 25).length;
    ws2.addRow(['INDICADORES MUNICIPAIS']);
    ws2.addRow(['Total de pacientes', children.length]);
    ws2.addRow(['Magreza (IMC < 14.5)', under]);
    ws2.addRow(['Sobrepeso/Obesidade (IMC ≥ 25)', over]);
    ws2.addRow(['Com alertas ativos', children.filter((c) => c.alerts.length > 0).length]);
    ws2.getColumn(1).width = 40; ws2.getColumn(2).width = 16;
    ws2.getRow(1).font = { bold: true, size: 14 };

    return Buffer.from(await wb.xlsx.writeBuffer());
  }

  private h(doc: any, t: string) { doc.fontSize(12).font('Helvetica-Bold').fillColor('#185FA5').text(t); doc.fillColor('black').moveDown(0.3); }
  private f(doc: any, l: string, v: string) { doc.fontSize(10).font('Helvetica-Bold').text(`${l}: `, { continued: true }); doc.font('Helvetica').text(v); }
}

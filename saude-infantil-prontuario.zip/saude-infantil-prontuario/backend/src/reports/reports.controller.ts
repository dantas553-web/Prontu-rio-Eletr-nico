import { Controller, Get, Param, Res, UseGuards } from '@nestjs/common';
import { Response } from 'express';
import { ReportsService } from './reports.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('reports')
export class ReportsController {
  constructor(private readonly reportsService: ReportsService) {}

  @Get('prontuario/:childId/pdf')
  async pdf(@Param('childId') childId: string, @Res() res: Response) {
    const buffer = await this.reportsService.generateProntuarioPdf(childId);
    res.set({
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="prontuario-${childId}.pdf"`,
    });
    res.end(buffer);
  }

  @Get('municipal/:municipalityId/excel')
  async excel(@Param('municipalityId') municipalityId: string, @Res() res: Response) {
    const buffer = await this.reportsService.generateMunicipalReport(municipalityId);
    res.set({
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="relatorio-municipal.xlsx"`,
    });
    res.end(buffer);
  }
}

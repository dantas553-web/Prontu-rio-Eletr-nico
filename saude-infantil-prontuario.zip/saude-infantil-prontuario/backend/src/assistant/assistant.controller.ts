import { Controller, Post, Body, UseGuards } from '@nestjs/common';
import { AssistantService } from './assistant.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('assistant')
export class AssistantController {
  constructor(private readonly assistantService: AssistantService) {}

  @Post('message')
  message(@Body() body: { message: string; childId?: string; municipalityId: string }) {
    return this.assistantService.handleMessage(body.message, {
      childId: body.childId,
      municipalityId: body.municipalityId,
    });
  }
}

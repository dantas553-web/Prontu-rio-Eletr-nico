import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';

/**
 * Assistente virtual de atendimento.
 * Responde perguntas frequentes (horários, agendas, procedimentos, CNS) e
 * consulta o status de atendimentos/agendamentos do paciente.
 *
 * A intenção é detectada por regras locais (rápido, sem custo) e, para
 * perguntas abertas, o frontend pode encaminhar à API do Claude (ver
 * AssistantChat.tsx). Aqui ficam as consultas estruturadas ao banco.
 */
@Injectable()
export class AssistantService {
  constructor(private prisma: PrismaService) {}

  async handleMessage(message: string, context: { childId?: string; municipalityId: string }) {
    const intent = this.detectIntent(message);

    switch (intent) {
      case 'HORARIO_UNIDADE':
        return this.unitHours(context.municipalityId);
      case 'AGENDA_PROFISSIONAL':
        return this.availableProfessionals(context.municipalityId);
      case 'MEUS_AGENDAMENTOS':
        return this.myAppointments(context.childId);
      case 'STATUS_ATENDIMENTO':
        return this.attendanceStatus(context.childId);
      case 'MEUS_ENCAMINHAMENTOS':
        return this.myReferrals(context.childId);
      case 'CNS':
        return this.cnsInfo(context.childId);
      default:
        return {
          type: 'FALLBACK',
          message:
            'Posso ajudar com: horários das unidades, profissionais disponíveis, ' +
            'seus agendamentos, status de atendimento, encaminhamentos e informações ' +
            'sobre o Cartão Nacional SUS (CNS). Sobre o que você gostaria de saber?',
          needsAI: true, // sinaliza ao frontend para usar IA na resposta livre
        };
    }
  }

  private detectIntent(message: string): string {
    const m = message.toLowerCase();
    if (/(horário|horario|abre|fecha|funciona|aberto)/.test(m)) return 'HORARIO_UNIDADE';
    if (/(profissional|médico|medico|disponível|disponivel|agenda do)/.test(m)) return 'AGENDA_PROFISSIONAL';
    if (/(meu agendamento|minha consulta|marcado|agendad)/.test(m)) return 'MEUS_AGENDAMENTOS';
    if (/(status|previsão|previsao|fila|chegou|chamado)/.test(m)) return 'STATUS_ATENDIMENTO';
    if (/(encaminhament|especialista|especializ)/.test(m)) return 'MEUS_ENCAMINHAMENTOS';
    if (/(cns|cartão sus|cartao sus|cartão nacional|número do sus)/.test(m)) return 'CNS';
    return 'UNKNOWN';
  }

  private async unitHours(municipalityId: string) {
    const units = await this.prisma.healthUnit.findMany({
      where: { municipalityId, active: true },
      select: { name: true, unitType: true, openingHours: true, phone: true, address: true },
    });
    return {
      type: 'HORARIO_UNIDADE',
      message: `Encontrei ${units.length} unidade(s) de saúde:`,
      data: units,
    };
  }

  private async availableProfessionals(municipalityId: string) {
    const slots = await this.prisma.agendaSlot.findMany({
      where: {
        available: true,
        date: { gte: new Date() },
        professional: { healthUnit: { municipalityId } },
      },
      include: { professional: { select: { name: true, specialty: true, cbo: true } } },
      orderBy: { date: 'asc' },
      take: 20,
    });
    return {
      type: 'AGENDA_PROFISSIONAL',
      message: `Há ${slots.length} horário(s) disponível(is) nos próximos dias:`,
      data: slots,
    };
  }

  private async myAppointments(childId?: string) {
    if (!childId) return { type: 'ERRO', message: 'Identifique o paciente para ver os agendamentos.' };
    const appts = await this.prisma.appointment.findMany({
      where: { childId, status: { in: ['AGENDADO', 'CONFIRMADO'] }, scheduledAt: { gte: new Date() } },
      include: {
        professional: { select: { name: true, specialty: true } },
        healthUnit: { select: { name: true, address: true } },
      },
      orderBy: { scheduledAt: 'asc' },
    });
    return {
      type: 'MEUS_AGENDAMENTOS',
      message: appts.length > 0
        ? `Você tem ${appts.length} agendamento(s):`
        : 'Não há consultas ou exames agendados no momento.',
      data: appts,
    };
  }

  private async attendanceStatus(childId?: string) {
    if (!childId) return { type: 'ERRO', message: 'Identifique o paciente.' };
    const todayAppt = await this.prisma.appointment.findFirst({
      where: {
        childId,
        scheduledAt: {
          gte: new Date(new Date().setHours(0, 0, 0, 0)),
          lt: new Date(new Date().setHours(23, 59, 59, 999)),
        },
      },
      include: { professional: { select: { name: true } }, healthUnit: { select: { name: true } } },
    });
    if (!todayAppt) {
      return { type: 'STATUS_ATENDIMENTO', message: 'Não há atendimento agendado para hoje.' };
    }
    const statusMsg: Record<string, string> = {
      AGENDADO: `Seu atendimento está agendado para ${new Date(todayAppt.scheduledAt).toLocaleTimeString('pt-BR')}. Previsão: ${todayAppt.estimatedTime ?? 'a confirmar'}.`,
      CONFIRMADO: 'Atendimento confirmado. Aguarde ser chamado.',
      EM_ATENDIMENTO: 'Você está em atendimento.',
      CONCLUIDO: 'Atendimento concluído.',
    };
    return {
      type: 'STATUS_ATENDIMENTO',
      message: statusMsg[todayAppt.status] ?? `Status: ${todayAppt.status}`,
      data: todayAppt,
    };
  }

  private async myReferrals(childId?: string) {
    if (!childId) return { type: 'ERRO', message: 'Identifique o paciente.' };
    const refs = await this.prisma.referral.findMany({
      where: { childId, status: { notIn: ['REALIZADO', 'CANCELADO'] } },
      orderBy: { createdAt: 'desc' },
    });
    return {
      type: 'MEUS_ENCAMINHAMENTOS',
      message: refs.length > 0
        ? `Você tem ${refs.length} encaminhamento(s) em andamento:`
        : 'Não há encaminhamentos pendentes.',
      data: refs,
    };
  }

  private async cnsInfo(childId?: string) {
    if (!childId) {
      return {
        type: 'CNS',
        message:
          'O Cartão Nacional de Saúde (CNS) identifica você no SUS. É necessário em todo ' +
          'atendimento. Caso não tenha, procure qualquer unidade de saúde com documento ' +
          'oficial com foto para o cadastro gratuito.',
      };
    }
    const child = await this.prisma.child.findUnique({
      where: { id: childId },
      select: { fullName: true, susCard: true },
    });
    return {
      type: 'CNS',
      message: child?.susCard
        ? `O CNS de ${child.fullName} é ${child.susCard}.`
        : 'Não há CNS cadastrado. Procure uma unidade de saúde para emissão.',
    };
  }
}

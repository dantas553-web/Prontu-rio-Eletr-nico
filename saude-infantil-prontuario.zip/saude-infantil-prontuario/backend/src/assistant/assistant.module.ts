import { Module } from '@nestjs/common';
import { AssistantController } from './assistant.controller';
import { AssistantService } from './assistant.service';
import { PrismaService } from '../common/prisma.service';

@Module({
  controllers: [AssistantController],
  providers: [AssistantService, PrismaService],
})
export class AssistantModule {}

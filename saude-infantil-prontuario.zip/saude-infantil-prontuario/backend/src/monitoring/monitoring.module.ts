import { Module } from '@nestjs/common';
import { MonitoringController } from './monitoring.controller';
import { MonitoringService } from './monitoring.service';
import { DataQualityModule } from '../data-quality/data-quality.module';
import { AlertsModule } from '../alerts/alerts.module';
import { PrismaService } from '../common/prisma.service';

@Module({
  imports: [DataQualityModule, AlertsModule],
  controllers: [MonitoringController],
  providers: [MonitoringService, PrismaService],
})
export class MonitoringModule {}

import { Controller, Get, Post, Query, UseGuards } from '@nestjs/common';
import { MonitoringService } from './monitoring.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';

@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('monitoring')
export class MonitoringController {
  constructor(private readonly monitoring: MonitoringService) {}

  @Get('health')
  health(@Query('municipalityId') municipalityId: string) {
    return this.monitoring.getSystemHealth(municipalityId);
  }

  @Post('daily-check')
  @Roles('ADMIN', 'SUPER_ADMIN')
  dailyCheck() {
    return this.monitoring.runDailyCheck();
  }
}

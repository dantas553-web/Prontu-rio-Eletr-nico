import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { DataQualityService } from '../data-quality/data-quality.service';
import { AlertsService } from '../alerts/alerts.service';

/**
 * Monitoramento diário dos dados.
 * Verifica integridade, consistência e atualização dos dados clínicos e
 * operacionais, gerando alertas e relatórios preventivos.
 *
 * Agende com @nestjs/schedule (Cron) ou um job externo (ex.: cron do SO).
 */
@Injectable()
export class MonitoringService {
  private readonly logger = new Logger(MonitoringService.name);

  constructor(
    private prisma: PrismaService,
    private dataQuality: DataQualityService,
    private alerts: AlertsService,
  ) {}

  /** Job diário — executar à meia-noite. */
  async runDailyCheck() {
    this.logger.log('Iniciando verificação diária de integridade…');
    const municipalities = await this.prisma.municipality.findMany({
      where: { active: true },
      select: { id: true, name: true },
    });

    const report: any[] = [];

    for (const m of municipalities) {
      // 1. Qualificação de dados
      const quality = await this.dataQuality.auditMunicipality(m.id);

      // 2. Regenerar alertas clínicos de todos os pacientes ativos
      const children = await this.prisma.child.findMany({
        where: { municipalityId: m.id, isActive: true },
        select: { id: true },
      });
      for (const c of children) {
        await this.alerts.generateAlerts(c.id);
      }

      // 3. Detectar produção BPA não exportada
      const pendingBpa = await this.prisma.bpaProduction.count({
        where: { municipalityId: m.id, exported: false },
      });

      // 4. Agendamentos não confirmados próximos
      const upcomingUnconfirmed = await this.prisma.appointment.count({
        where: {
          status: 'AGENDADO',
          scheduledAt: { gte: new Date(), lte: new Date(Date.now() + 2 * 86400000) },
          child: { municipalityId: m.id },
        },
      });

      report.push({
        municipality: m.name,
        qualityScore: quality.qualityScore,
        dataIssues: quality.totalIssues,
        criticalIssues: quality.bySeverity.ALTA,
        pendingBpaRecords: pendingBpa,
        upcomingUnconfirmed,
        checkedAt: new Date().toISOString(),
      });

      this.logger.log(
        `${m.name}: qualidade ${quality.qualityScore}% · ${quality.totalIssues} issues · ${pendingBpa} BPA pendentes`,
      );
    }

    return report;
  }

  /** Snapshot de saúde do sistema para dashboard de gestão. */
  async getSystemHealth(municipalityId: string) {
    const [totalChildren, activeAlerts, openIssues, pendingReferrals, todayAppointments] =
      await Promise.all([
        this.prisma.child.count({ where: { municipalityId, isActive: true } }),
        this.prisma.alert.count({ where: { resolved: false, child: { municipalityId } } }),
        this.prisma.dataQualityIssue.count({ where: { resolved: false } }),
        this.prisma.referral.count({ where: { status: 'PENDENTE', child: { municipalityId } } }),
        this.prisma.appointment.count({
          where: {
            child: { municipalityId },
            scheduledAt: {
              gte: new Date(new Date().setHours(0, 0, 0, 0)),
              lt: new Date(new Date().setHours(23, 59, 59, 999)),
            },
          },
        }),
      ]);

    return { totalChildren, activeAlerts, openIssues, pendingReferrals, todayAppointments };
  }
}

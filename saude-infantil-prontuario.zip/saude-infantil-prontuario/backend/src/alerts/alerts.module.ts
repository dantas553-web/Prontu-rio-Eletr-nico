import { Module } from '@nestjs/common';
import { AlertsService } from './alerts.service';
import { PrismaService } from '../common/prisma.service';

@Module({
  providers: [AlertsService, PrismaService],
  exports: [AlertsService],
})
export class AlertsModule {}

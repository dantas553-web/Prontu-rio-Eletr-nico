import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';

@Injectable()
export class AlertsService {
  constructor(private prisma: PrismaService) {}

  // Calendário vacinal PNI (meses de vida)
  private readonly VACCINE_SCHEDULE: Record<string, number> = {
    'BCG': 0, 'Hepatite B': 0,
    'Pentavalente D1': 2, 'VIP D1': 2, 'Pneumocócica 10V D1': 2, 'Rotavírus D1': 2,
    'Meningocócica C D1': 3,
    'Pentavalente D2': 4, 'VIP D2': 4, 'Pneumocócica 10V D2': 4, 'Rotavírus D2': 4,
    'Meningocócica C D2': 5,
    'Pentavalente D3': 6, 'VIP D3': 6,
    'Febre Amarela': 9,
    'Tríplice Viral D1': 12, 'Pneumocócica 10V Reforço': 12, 'Meningocócica C Reforço': 12,
    'Tríplice Viral D2': 15, 'DTP Reforço 1': 15, 'VOP Reforço 1': 15, 'Hepatite A': 15, 'Varicela': 15,
    'DTP Reforço 2': 48, 'VOP Reforço 2': 48,
    'HPV D1': 120,
  };

  async generateAlerts(childId: string): Promise<void> {
    const child = await this.prisma.child.findUnique({
      where: { id: childId },
      include: {
        vaccines: true,
        growthRecords: { orderBy: { createdAt: 'desc' }, take: 1 },
        medicalRecords: { orderBy: { appointmentDate: 'desc' }, take: 1 },
        alerts: { where: { resolved: false } },
      },
    });
    if (!child) return;

    const ageMonths = this.getAgeInMonths(child.birthDate);
    const existingTypes = new Set(child.alerts.map((a) => a.type));
    const appliedVaccines = new Set(child.vaccines.map((v) => v.name));

    for (const [vaccineName, dueMonth] of Object.entries(this.VACCINE_SCHEDULE)) {
      if (ageMonths >= dueMonth + 1 && !appliedVaccines.has(vaccineName)) {
        const t = `VACINA_${vaccineName.replace(/\s/g, '_').toUpperCase()}`;
        if (!existingTypes.has(t)) {
          await this.createAlert(childId, t, 'ALTA',
            `Vacina em atraso: ${vaccineName} (prevista aos ${dueMonth} meses)`);
        }
      }
    }

    const lastGrowth = child.growthRecords[0];
    if (lastGrowth) {
      if (lastGrowth.imc < 13 && !existingTypes.has('MAGREZA_SEVERA'))
        await this.createAlert(childId, 'MAGREZA_SEVERA', 'CRITICA',
          `IMC ${lastGrowth.imc} — Magreza severa. Avaliação nutricional urgente.`);
      else if (lastGrowth.imc < 14.5 && !existingTypes.has('MAGREZA_GRAU_I'))
        await this.createAlert(childId, 'MAGREZA_GRAU_I', 'ALTA',
          `IMC ${lastGrowth.imc} — Magreza grau I. Acompanhamento indicado.`);
      else if (lastGrowth.imc >= 30 && !existingTypes.has('OBESIDADE'))
        await this.createAlert(childId, 'OBESIDADE', 'ALTA',
          `IMC ${lastGrowth.imc} — Obesidade. Intervenção indicada.`);
      else if (lastGrowth.imc >= 25 && !existingTypes.has('SOBREPESO'))
        await this.createAlert(childId, 'SOBREPESO', 'MEDIA',
          `IMC ${lastGrowth.imc} — Sobrepeso. Orientação alimentar recomendada.`);
    }

    const lastConsult = child.medicalRecords[0];
    if (lastConsult) {
      const days = Math.floor((Date.now() - new Date(lastConsult.appointmentDate).getTime()) / 86400000);
      if (days > 90 && !existingTypes.has('SEM_ACOMPANHAMENTO'))
        await this.createAlert(childId, 'SEM_ACOMPANHAMENTO', 'MEDIA',
          `Sem consulta há ${days} dias. Agendar retorno.`);
    } else if (!existingTypes.has('SEM_CONSULTA')) {
      await this.createAlert(childId, 'SEM_CONSULTA', 'MEDIA', 'Paciente sem consultas registradas.');
    }
  }

  async resolveAlert(alertId: string, resolvedBy: string) {
    return this.prisma.alert.update({
      where: { id: alertId },
      data: { resolved: true, resolvedAt: new Date(), resolvedBy },
    });
  }

  async getAlertsByMunicipality(municipalityId: string) {
    return this.prisma.alert.findMany({
      where: { resolved: false, child: { municipalityId } },
      include: { child: { select: { fullName: true, birthDate: true, neighborhood: true } } },
      orderBy: [{ severity: 'desc' }, { createdAt: 'desc' }],
    });
  }

  private async createAlert(childId: string, type: string, severity: string, message: string) {
    return this.prisma.alert.create({ data: { childId, type, severity: severity as any, message } });
  }

  private getAgeInMonths(birthDate: Date): number {
    const now = new Date();
    return (now.getFullYear() - birthDate.getFullYear()) * 12 + now.getMonth() - birthDate.getMonth();
  }
}

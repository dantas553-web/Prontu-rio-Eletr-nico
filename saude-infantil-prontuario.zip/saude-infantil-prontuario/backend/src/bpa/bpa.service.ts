import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';

/**
 * Gerador de Boletim de Produção Ambulatorial (BPA) — SIA/SUS.
 *
 * Produz:
 *  - BPA-C (Consolidado): linhas tipo "02", produção agregada por procedimento.
 *  - BPA-I (Individualizado): linhas tipo "03", produção por paciente (CNS/CID/CBO).
 *  - Arquivo magnético completo com cabeçalho "01" + "#BPA#" para importação no SIA.
 *
 * ⚠ IMPORTANTE: as larguras de campo e a string de versão seguem o layout
 * histórico do DATASUS. Antes do envio em produção, valide cada posição contra
 * o "Layout_Exportacao_BPA.pdf" da competência-alvo (publicado no Portal do SIA),
 * pois o Ministério da Saúde versiona o layout periodicamente.
 */
@Injectable()
export class BpaService {
  constructor(private prisma: PrismaService) {}

  // ── Helpers de formatação de campo fixo ──────────────
  private numField(value: string | number, size: number): string {
    return String(value ?? '').replace(/\D/g, '').padStart(size, '0').slice(-size);
  }
  private txtField(value: string, size: number): string {
    return (value ?? '').toUpperCase().padEnd(size, ' ').slice(0, size);
  }

  /**
   * Campo de controle do cabeçalho (domínio [1111..2221]).
   * Algoritmo clássico: (soma de todos os códigos de procedimento) % 1111 + 1111.
   */
  private controlField(procedureCodes: string[]): string {
    const sum = procedureCodes.reduce((acc, c) => acc + Number(c.replace(/\D/g, '') || 0), 0);
    return String((sum % 1111) + 1111);
  }

  /**
   * Gera o arquivo magnético BPA para uma competência (AAAAMM) e CNES.
   */
  async generateMagneticFile(params: {
    competencia: string;           // AAAAMM
    cnes: string;                  // 7 dígitos
    municipalityId: string;
    orgaoOrigemNome: string;       // nome do estabelecimento/órgão
    orgaoOrigemSigla: string;
    cgcCpf: string;                // 14 dígitos (CNPJ) ou CPF
    orgaoDestinoNome: string;      // SMS / SES
    indicadorDestino: 'M' | 'E';   // Municipal | Estadual
    versaoSistema: string;         // ex.: 'v04.10p'
  }): Promise<string> {
    const consolidado = await this.buildBpaC(params.competencia, params.cnes, params.municipalityId);
    const individualizado = await this.buildBpaI(params.competencia, params.cnes, params.municipalityId);

    const allLines = [...consolidado.lines, ...individualizado.lines];
    const allProcedureCodes = [...consolidado.codes, ...individualizado.codes];
    const totalFolhas = consolidado.folhas + individualizado.folhas;

    const header = this.buildHeader({
      ...params,
      numLinhas: allLines.length,
      numFolhas: totalFolhas,
      controlField: this.controlField(allProcedureCodes),
    });

    return [header, ...allLines].join('\r\n') + '\r\n';
  }

  // ── Cabeçalho (tipo 01) ──────────────────────────────
  private buildHeader(p: {
    competencia: string;
    numLinhas: number;
    numFolhas: number;
    controlField: string;
    orgaoOrigemNome: string;
    orgaoOrigemSigla: string;
    cgcCpf: string;
    orgaoDestinoNome: string;
    indicadorDestino: string;
    versaoSistema: string;
  }): string {
    return [
      '01',                                          // 02 — identificador de cabeçalho
      '#BPA#',                                        // 05 — literal
      this.numField(p.competencia, 6),               // 06 — AAAAMM de processamento
      this.numField(p.numLinhas, 6),                 // 06 — nº de linhas gravadas
      this.numField(p.numFolhas, 6),                 // 06 — nº de folhas gravadas
      this.numField(p.controlField, 4),              // 04 — campo de controle [1111..2221]
      this.txtField(p.orgaoOrigemNome, 30),          // 30 — nome órgão origem
      this.txtField(p.orgaoOrigemSigla, 6),          // 06 — sigla órgão origem
      this.numField(p.cgcCpf, 14),                   // 14 — CNPJ/CPF do prestador
      this.txtField(p.orgaoDestinoNome, 40),         // 40 — nome do órgão destino
      this.txtField(p.indicadorDestino, 1),          // 01 — M (municipal) / E (estadual)
      this.txtField(p.versaoSistema, 10),            // 10 — versão do sistema gerador
    ].join('');
  }

  // ── BPA-C (Consolidado, tipo 02) ─────────────────────
  private async buildBpaC(competencia: string, cnes: string, municipalityId: string) {
    // Procedimentos de registro consolidado (sem identificação do paciente),
    // agregados por procedimento + CBO + idade.
    const records = await this.prisma.bpaProduction.groupBy({
      by: ['procedureCode', 'cboCode', 'ageRange'],
      where: { competencia, cnes, municipalityId, registrationType: 'CONSOLIDADO' },
      _sum: { quantity: true },
    });

    const lines: string[] = [];
    const codes: string[] = [];
    let folha = 1;
    let seq = 1;

    for (const r of records) {
      const line = [
        '02',                                      // tipo de linha BPA-C
        this.numField(cnes, 7),                    // CNES
        this.numField(competencia, 6),             // competência AAAAMM
        this.numField(r.cboCode ?? '', 6),         // CBO
        this.numField(folha, 3),                   // nº da folha
        this.numField(seq, 2),                     // nº sequencial na folha
        this.numField(r.procedureCode, 10),        // código SIGTAP do procedimento
        this.numField(r.ageRange ?? '', 3),        // faixa etária
        this.numField(r._sum.quantity ?? 0, 6),    // quantidade produzida
      ].join('');
      lines.push(line);
      codes.push(r.procedureCode);

      seq++;
      if (seq > 20) { seq = 1; folha++; }            // até 20 linhas por folha
    }

    return { lines, codes, folhas: folha };
  }

  // ── BPA-I (Individualizado, tipo 03) ─────────────────
  private async buildBpaI(competencia: string, cnes: string, municipalityId: string) {
    const records = await this.prisma.bpaProduction.findMany({
      where: { competencia, cnes, municipalityId, registrationType: 'INDIVIDUALIZADO' },
      include: {
        child: { select: { fullName: true, susCard: true, birthDate: true, gender: true, cep: true } },
      },
      orderBy: { createdAt: 'asc' },
    });

    const lines: string[] = [];
    const codes: string[] = [];
    let folha = 1;
    let seq = 1;

    for (const r of records) {
      const c = r.child;
      const line = [
        '03',                                      // tipo de linha BPA-I
        this.numField(cnes, 7),                    // CNES
        this.numField(competencia, 6),             // competência AAAAMM
        this.numField(r.cnsProfessional ?? '', 15),// CNS do profissional
        this.numField(r.cboCode ?? '', 6),         // CBO
        this.numField(r.attendanceDate ? this.toAAAAMMDD(r.attendanceDate) : '', 8), // data atendimento
        this.numField(folha, 3),                   // folha
        this.numField(seq, 2),                     // sequência
        this.numField(r.procedureCode, 10),        // procedimento SIGTAP
        this.numField(c?.susCard ?? '', 15),       // CNS do paciente
        this.txtField(c?.gender === 'Masculino' ? 'M' : 'F', 1),  // sexo
        this.numField(r.serviceCode ?? '', 3),     // código do serviço
        this.numField(r.classificationCode ?? '', 3), // classificação
        this.numField(r.authorization ?? '', 13),  // nº autorização (opcional)
        this.txtField(c?.fullName ?? '', 30),      // nome do paciente
        this.numField(c?.birthDate ? this.toAAAAMMDD(c.birthDate) : '', 8), // data nascimento
        this.numField(r.quantity, 6),              // quantidade
        this.txtField(r.cid10 ?? '', 4),           // CID-10
        this.numField(r.ageYears ?? '', 3),        // idade
      ].join('');
      lines.push(line);
      codes.push(r.procedureCode);

      seq++;
      if (seq > 20) { seq = 1; folha++; }
    }

    return { lines, codes, folhas: folha };
  }

  // ── Relatório de produção (BPA-C + BPA-I) em JSON ─────
  async getProductionReport(competencia: string, cnes: string, municipalityId: string) {
    const all = await this.prisma.bpaProduction.findMany({
      where: { competencia, cnes, municipalityId },
      include: { child: { select: { fullName: true, susCard: true } } },
    });

    const byProcedure = all.reduce((acc, r) => {
      acc[r.procedureCode] = (acc[r.procedureCode] ?? 0) + r.quantity;
      return acc;
    }, {} as Record<string, number>);

    const byProfessional = all.reduce((acc, r) => {
      const key = r.cnsProfessional ?? 'SEM_CNS';
      acc[key] = (acc[key] ?? 0) + r.quantity;
      return acc;
    }, {} as Record<string, number>);

    return {
      competencia,
      cnes,
      totalProcedimentos: all.reduce((s, r) => s + r.quantity, 0),
      totalAtendimentos: all.length,
      consolidado: all.filter((r) => r.registrationType === 'CONSOLIDADO').length,
      individualizado: all.filter((r) => r.registrationType === 'INDIVIDUALIZADO').length,
      porProcedimento: byProcedure,
      porProfissional: byProfessional,
    };
  }

  /**
   * Registra produção ambulatorial a partir de uma consulta concluída.
   * Chamado automaticamente ao finalizar um MedicalRecord.
   */
  async registerProduction(data: {
    childId: string;
    municipalityId: string;
    cnes: string;
    competencia: string;
    procedureCode: string;       // SIGTAP
    registrationType: 'CONSOLIDADO' | 'INDIVIDUALIZADO';
    quantity: number;
    cboCode?: string;
    cnsProfessional?: string;
    cid10?: string;
    attendanceDate?: Date;
    ageYears?: number;
    ageRange?: string;
    serviceCode?: string;
    classificationCode?: string;
    authorization?: string;
  }) {
    return this.prisma.bpaProduction.create({ data });
  }

  private toAAAAMMDD(date: Date): string {
    const d = new Date(date);
    return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  }
}

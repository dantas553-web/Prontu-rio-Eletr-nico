import { Controller, Get, Post, Body, Query, Res, UseGuards } from '@nestjs/common';
import { Response } from 'express';
import { BpaService } from './bpa.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';

@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('bpa')
export class BpaController {
  constructor(private readonly bpaService: BpaService) {}

  // Relatório de produção (BPA-C + BPA-I)
  @Get('producao')
  @Roles('GESTOR', 'ADMIN', 'SUPER_ADMIN')
  getProduction(
    @Query('competencia') competencia: string,
    @Query('cnes') cnes: string,
    @Query('municipalityId') municipalityId: string,
  ) {
    return this.bpaService.getProductionReport(competencia, cnes, municipalityId);
  }

  // Gera e baixa o arquivo magnético BPA para o SIA
  @Post('exportar')
  @Roles('GESTOR', 'ADMIN', 'SUPER_ADMIN')
  async export(@Body() body: any, @Res() res: Response) {
    const content = await this.bpaService.generateMagneticFile(body);
    const filename = `BPA${body.competencia}.txt`;
    res.set({
      'Content-Type': 'text/plain; charset=latin1',
      'Content-Disposition': `attachment; filename="${filename}"`,
    });
    res.end(content);
  }

  // Registro manual de produção
  @Post('producao')
  @Roles('MEDICO', 'ENFERMEIRO', 'DIGITADOR', 'ADMIN')
  register(@Body() body: any) {
    return this.bpaService.registerProduction(body);
  }
}

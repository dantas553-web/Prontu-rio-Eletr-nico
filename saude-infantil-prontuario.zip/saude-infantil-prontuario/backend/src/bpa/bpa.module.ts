import { Module } from '@nestjs/common';
import { BpaController } from './bpa.controller';
import { BpaService } from './bpa.service';
import { PrismaService } from '../common/prisma.service';

@Module({
  controllers: [BpaController],
  providers: [BpaService, PrismaService],
  exports: [BpaService],
})
export class BpaModule {}

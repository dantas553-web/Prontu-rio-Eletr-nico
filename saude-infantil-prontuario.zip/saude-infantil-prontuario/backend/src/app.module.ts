import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';

import { PrismaService } from './common/prisma.service';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { MunicipalitiesModule } from './municipalities/municipalities.module';
import { ChildrenModule } from './children/children.module';
import { ProntuarioModule } from './prontuario/prontuario.module';
import { AlertsModule } from './alerts/alerts.module';
import { ReportsModule } from './reports/reports.module';
import { AiModule } from './ai/ai.module';
import { VaccinesModule } from './vaccines/vaccines.module';
import { BpaModule } from './bpa/bpa.module';
import { AssistantModule } from './assistant/assistant.module';
import { DataQualityModule } from './data-quality/data-quality.module';
import { MonitoringModule } from './monitoring/monitoring.module';
import { SchedulingModule } from './scheduling/scheduling.module';
import { ReferralsModule } from './referrals/referrals.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ThrottlerModule.forRoot([{ ttl: 60000, limit: 100 }]),
    AuthModule,
    UsersModule,
    MunicipalitiesModule,
    ChildrenModule,
    ProntuarioModule,
    AlertsModule,
    ReportsModule,
    AiModule,
    VaccinesModule,
    BpaModule,
    AssistantModule,
    DataQualityModule,
    MonitoringModule,
    SchedulingModule,
    ReferralsModule,
  ],
  providers: [PrismaService],
  exports: [PrismaService],
})
export class AppModule {}

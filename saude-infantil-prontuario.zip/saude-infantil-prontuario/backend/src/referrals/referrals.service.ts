import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';

/**
 * Atenção especializada e encaminhamentos.
 * Fluxo de regulação: PENDENTE → REGULADO → AGENDADO → REALIZADO.
 */
@Injectable()
export class ReferralsService {
  constructor(private prisma: PrismaService) {}

  async create(data: {
    childId: string; fromProfessionalId?: string; specialty: string;
    priority?: string; reason: string; clinicalSummary?: string; cid10?: string;
  }) {
    const referral = await this.prisma.referral.create({ data });
    // Notifica o paciente sobre a necessidade de consulta especializada
    await this.prisma.alert.create({
      data: {
        childId: data.childId,
        type: 'ENCAMINHAMENTO',
        severity: data.priority === 'URGENTE' ? 'ALTA' : 'MEDIA',
        message: `Encaminhamento para ${data.specialty} (${data.priority ?? 'ELETIVO'}): ${data.reason}`,
      },
    });
    return referral;
  }

  async getByChild(childId: string) {
    return this.prisma.referral.findMany({
      where: { childId },
      include: { fromProfessional: { select: { name: true, specialty: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getPending(municipalityId: string) {
    return this.prisma.referral.findMany({
      where: { status: 'PENDENTE', child: { municipalityId } },
      include: { child: { select: { fullName: true, birthDate: true } } },
      orderBy: [{ priority: 'asc' }, { createdAt: 'asc' }],
    });
  }

  async regulate(id: string, scheduledAt?: Date) {
    return this.prisma.referral.update({
      where: { id },
      data: {
        status: scheduledAt ? 'AGENDADO' : 'REGULADO',
        regulatedAt: new Date(),
        scheduledAt,
      },
    });
  }

  async complete(id: string) {
    return this.prisma.referral.update({ where: { id }, data: { status: 'REALIZADO' } });
  }
}

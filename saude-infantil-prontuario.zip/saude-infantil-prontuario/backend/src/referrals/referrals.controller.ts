import { Controller, Get, Post, Patch, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ReferralsService } from './referrals.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';

@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('referrals')
export class ReferralsController {
  constructor(private readonly referrals: ReferralsService) {}

  @Post()
  @Roles('MEDICO', 'ENFERMEIRO')
  create(@Body() body: any) {
    return this.referrals.create(body);
  }

  @Get('child/:childId')
  byChild(@Param('childId') childId: string) {
    return this.referrals.getByChild(childId);
  }

  @Get('pending')
  @Roles('GESTOR', 'ADMIN', 'SUPER_ADMIN')
  pending(@Query('municipalityId') municipalityId: string) {
    return this.referrals.getPending(municipalityId);
  }

  @Patch(':id/regulate')
  @Roles('GESTOR', 'ADMIN')
  regulate(@Param('id') id: string, @Body() body: { scheduledAt?: string }) {
    return this.referrals.regulate(id, body.scheduledAt ? new Date(body.scheduledAt) : undefined);
  }

  @Patch(':id/complete')
  complete(@Param('id') id: string) {
    return this.referrals.complete(id);
  }
}

import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';

@Injectable()
export class SchedulingService {
  constructor(private prisma: PrismaService) {}

  // Agendamentos do paciente (consultas e exames)
  async getByChild(childId: string) {
    return this.prisma.appointment.findMany({
      where: { childId },
      include: {
        professional: { select: { name: true, specialty: true } },
        healthUnit: { select: { name: true, address: true } },
      },
      orderBy: { scheduledAt: 'desc' },
    });
  }

  // Horários disponíveis de um profissional
  async availableSlots(professionalId: string, from: Date, to: Date) {
    return this.prisma.agendaSlot.findMany({
      where: { professionalId, available: true, date: { gte: from, lte: to } },
      orderBy: { date: 'asc' },
    });
  }

  // Criar agendamento e ocupar o slot
  async schedule(data: {
    childId: string; professionalId?: string; healthUnitId?: string;
    type: string; specialty?: string; scheduledAt: Date; slotId?: string;
    estimatedTime?: string; procedureCode?: string;
  }) {
    const appointment = await this.prisma.appointment.create({ data: {
      childId: data.childId, professionalId: data.professionalId,
      healthUnitId: data.healthUnitId, type: data.type, specialty: data.specialty,
      scheduledAt: data.scheduledAt, estimatedTime: data.estimatedTime,
      procedureCode: data.procedureCode,
    }});
    if (data.slotId) {
      await this.prisma.agendaSlot.update({ where: { id: data.slotId }, data: { available: false } });
    }
    return appointment;
  }

  // Atualiza status (acompanhamento de atendimento)
  async updateStatus(id: string, status: string, estimatedTime?: string) {
    return this.prisma.appointment.update({ where: { id }, data: { status, estimatedTime } });
  }

  // Fila do dia por unidade (painel de chamada)
  async todayQueue(healthUnitId: string) {
    return this.prisma.appointment.findMany({
      where: {
        healthUnitId,
        scheduledAt: {
          gte: new Date(new Date().setHours(0, 0, 0, 0)),
          lt: new Date(new Date().setHours(23, 59, 59, 999)),
        },
      },
      include: { child: { select: { fullName: true } }, professional: { select: { name: true } } },
      orderBy: { scheduledAt: 'asc' },
    });
  }
}

import { Controller, Get, Post, Patch, Body, Param, Query, UseGuards } from '@nestjs/common';
import { SchedulingService } from './scheduling.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('scheduling')
export class SchedulingController {
  constructor(private readonly scheduling: SchedulingService) {}

  @Get('child/:childId')
  byChild(@Param('childId') childId: string) {
    return this.scheduling.getByChild(childId);
  }

  @Get('slots/:professionalId')
  slots(@Param('professionalId') id: string, @Query('from') from: string, @Query('to') to: string) {
    return this.scheduling.availableSlots(id, new Date(from), new Date(to));
  }

  @Get('queue/:healthUnitId')
  queue(@Param('healthUnitId') id: string) {
    return this.scheduling.todayQueue(id);
  }

  @Post()
  schedule(@Body() body: any) {
    return this.scheduling.schedule({ ...body, scheduledAt: new Date(body.scheduledAt) });
  }

  @Patch(':id/status')
  status(@Param('id') id: string, @Body() body: { status: string; estimatedTime?: string }) {
    return this.scheduling.updateStatus(id, body.status, body.estimatedTime);
  }
}

"""
Sistema Municipal de Saúde — Serviço de IA
FastAPI + Scikit-Learn. Predição de risco e análise epidemiológica.
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional, List
import numpy as np
import joblib
import os
from datetime import datetime

app = FastAPI(title="Saúde Municipal — IA", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:3001"],
    allow_methods=["*"], allow_headers=["*"],
)

MODEL_PATH = "models/risk_model.pkl"
model = None


@app.on_event("startup")
async def load_model():
    global model
    if os.path.exists(MODEL_PATH):
        model = joblib.load(MODEL_PATH)


class ChildRiskInput(BaseModel):
    age_months: int = Field(..., ge=0, le=216)
    weight: float = Field(..., gt=0)
    height: float = Field(..., gt=0)
    vaccine_status: int = Field(..., ge=0, le=4)
    consultations_last_6m: int = Field(default=0, ge=0)
    has_chronic_disease: int = Field(default=0, ge=0, le=1)
    nutritional_status: int = Field(default=2, ge=0, le=4)
    socioeconomic_score: int = Field(default=2, ge=0, le=4)
    alerts_count: int = Field(default=0, ge=0)


class RiskPrediction(BaseModel):
    risk_level: str
    risk_score: float
    probability: float
    recommendations: List[str]
    imc: float
    nutritional_status_label: str
    generated_at: str


class EpidemiologicalInput(BaseModel):
    children: List[ChildRiskInput]
    municipality_name: Optional[str] = None


@app.get("/")
def health():
    return {"status": "ok", "model_loaded": model is not None}


@app.post("/predict", response_model=RiskPrediction)
def predict(data: ChildRiskInput):
    imc = round(data.weight / (data.height / 100) ** 2, 1)
    if model is None:
        score = _rule_based_score(data, imc)
    else:
        features = np.array([[
            data.age_months, data.weight, data.height, imc, data.vaccine_status,
            data.consultations_last_6m, data.has_chronic_disease,
            data.nutritional_status, data.socioeconomic_score, data.alerts_count,
        ]])
        score = float(model.predict_proba(features)[0][1])
    return RiskPrediction(
        risk_level=_risk_level(score), risk_score=round(score, 3),
        probability=round(score * 100, 1), recommendations=_recommendations(data, imc, score),
        imc=imc, nutritional_status_label=_nutritional_label(imc),
        generated_at=datetime.now().isoformat(),
    )


@app.post("/epidemiological")
def epidemiological(data: EpidemiologicalInput):
    children = data.children
    if not children:
        raise HTTPException(status_code=400, detail="Lista vazia.")
    imcs = [c.weight / (c.height / 100) ** 2 for c in children]
    risks = [_rule_based_score(c, imc) for c, imc in zip(children, imcs)]
    high = [r for r in risks if r >= 0.6]
    under = [i for i in imcs if i < 14.5]
    over = [i for i in imcs if i >= 25]
    incomplete = [c for c in children if c.vaccine_status < 3]
    factors = []
    if len(incomplete) / len(children) > 0.2:
        factors.append(f"{len(incomplete)} crianças com vacinação incompleta")
    if len(under) / len(children) > 0.1:
        factors.append(f"{len(under)} crianças com magreza")
    no_consult = sum(1 for c in children if c.consultations_last_6m == 0)
    if no_consult:
        factors.append(f"{no_consult} sem consulta nos últimos 6 meses")
    return {
        "total": len(children), "high_risk_count": len(high),
        "high_risk_pct": round(len(high) / len(children) * 100, 1),
        "avg_imc": round(float(np.mean(imcs)), 1),
        "underweight_count": len(under), "overweight_count": len(over),
        "incomplete_vaccines_count": len(incomplete),
        "top_risk_factors": factors, "generated_at": datetime.now().isoformat(),
    }


def _rule_based_score(data, imc):
    s = 0.0
    if imc < 13: s += 0.35
    elif imc < 14.5: s += 0.20
    elif imc >= 30: s += 0.15
    elif imc >= 25: s += 0.08
    if data.vaccine_status == 0: s += 0.25
    elif data.vaccine_status == 1: s += 0.15
    elif data.vaccine_status == 2: s += 0.10
    if data.consultations_last_6m == 0: s += 0.20
    elif data.consultations_last_6m == 1: s += 0.10
    if data.has_chronic_disease: s += 0.10
    if data.socioeconomic_score <= 1: s += 0.10
    elif data.socioeconomic_score == 2: s += 0.05
    s += min(data.alerts_count * 0.05, 0.15)
    return min(s, 1.0)


def _risk_level(s):
    if s >= 0.75: return "CRITICO"
    if s >= 0.50: return "ALTO"
    if s >= 0.25: return "MEDIO"
    return "BAIXO"


def _nutritional_label(imc):
    if imc < 13: return "Magreza severa"
    if imc < 14.5: return "Magreza grau I"
    if imc < 17: return "Magreza grau II"
    if imc < 25: return "Eutrófico"
    if imc < 30: return "Sobrepeso"
    if imc < 35: return "Obesidade grau I"
    return "Obesidade grau II+"


def _recommendations(data, imc, score):
    r = []
    if imc < 14.5: r.append("Encaminhar para avaliação nutricional.")
    if imc >= 25: r.append("Orientação alimentar e atividade física.")
    if data.vaccine_status < 3: r.append("Atualizar calendário vacinal (PNI).")
    if data.consultations_last_6m == 0: r.append("Agendar consulta de puericultura.")
    if data.has_chronic_disease: r.append("Manter acompanhamento da doença crônica.")
    if score >= 0.6: r.append("Alto risco — acionar equipe de saúde da família.")
    if not r: r.append("Bom estado geral. Manter rotina.")
    return r

"""Treina o modelo de risco. Execute: python training/train.py"""
import numpy as np, pandas as pd, joblib, os
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, roc_auc_score

RS, N = 42, 5000
np.random.seed(RS)
print("Treinamento do modelo de risco infantil\n" + "=" * 50)

age = np.random.randint(0, 144, N)
weight = np.random.normal(15, 5, N).clip(3, 60)
height = np.random.normal(100, 20, N).clip(45, 160)
imc = weight / (height / 100) ** 2
vac = np.random.choice([0,1,2,3,4], N, p=[.05,.10,.20,.40,.25])
cons = np.random.poisson(2, N).clip(0, 10)
chronic = np.random.binomial(1, .12, N)
nut = np.digitize(imc, [13, 14.5, 17, 25, 30])
socio = np.random.choice([0,1,2,3,4], N, p=[.10,.20,.35,.25,.10])
alerts = np.random.poisson(.5, N).clip(0, 8)

risk = ((imc<14.5).astype(int)*3 + (vac<2).astype(int)*2 + (cons==0).astype(int)*2
        + chronic + (socio<=1).astype(int) + (alerts>=2).astype(int)
        + np.random.binomial(1, .05, N))
y = (risk >= 4).astype(int)

X = pd.DataFrame({'age_months':age,'weight':weight,'height':height,'imc':imc,
    'vaccine_status':vac,'consultations_last_6m':cons,'has_chronic_disease':chronic,
    'nutritional_status':nut,'socioeconomic_score':socio,'alerts_count':alerts})

print(f"Dataset: {N} amostras | Alto risco: {y.sum()} ({y.mean()*100:.1f}%)")
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.2, random_state=RS, stratify=y)
pipe = Pipeline([('scaler', StandardScaler()),
    ('model', GradientBoostingClassifier(n_estimators=200, max_depth=4,
        learning_rate=.05, subsample=.8, random_state=RS))])
pipe.fit(Xtr, ytr)
print(classification_report(yte, pipe.predict(Xte), target_names=['Baixo','Alto']))
print(f"AUC-ROC: {roc_auc_score(yte, pipe.predict_proba(Xte)[:,1]):.3f}")
cv = cross_val_score(pipe, X, y, cv=5, scoring='roc_auc')
print(f"CV AUC-ROC: {cv.mean():.3f} ± {cv.std():.3f}")
os.makedirs('../models', exist_ok=True)
joblib.dump(pipe, '../models/risk_model.pkl')
print("Modelo salvo em ../models/risk_model.pkl")

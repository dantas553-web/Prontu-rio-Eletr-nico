# Segurança da Informação & LGPD

Guia de conformidade para o Sistema Municipal de Saúde. Dados de saúde são
**dados sensíveis** (LGPD art. 5º, II) e de menores de idade — exigem proteção reforçada.

---

## 1. Autenticação multifatorial (MFA)

Implementação com TOTP (compatível com Google Authenticator/Authy):

```bash
cd backend
npm install otplib qrcode
```

```ts
// auth/mfa.service.ts
import { authenticator } from 'otplib';
import * as QRCode from 'qrcode';

export class MfaService {
  generateSecret(email: string) {
    const secret = authenticator.generateSecret();
    const otpauth = authenticator.keyuri(email, 'SaudeInfantil', secret);
    return { secret, otpauth };
  }

  async generateQR(otpauth: string) {
    return QRCode.toDataURL(otpauth);
  }

  verify(token: string, secret: string): boolean {
    return authenticator.verify({ token, secret });
  }
}
```

Fluxo: login com senha → se `user.mfaEnabled`, exigir código TOTP antes de emitir o JWT
definitivo. Armazene `mfaSecret` criptografado (ver seção 2).

Adicione ao `User`:
```prisma
mfaEnabled  Boolean @default(false)
mfaSecret   String?   // criptografado
```

---

## 2. Criptografia de dados sensíveis

### Em repouso (campos sensíveis no banco)

```ts
// common/crypto.service.ts
import * as crypto from 'crypto';

const ALGO = 'aes-256-gcm';
const KEY = crypto.scryptSync(process.env.CRYPTO_SECRET!, 'salt', 32);

export function encrypt(text: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGO, KEY, iv);
  const enc = Buffer.concat([cipher.update(text, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString('hex')}:${tag.toString('hex')}:${enc.toString('hex')}`;
}

export function decrypt(payload: string): string {
  const [ivHex, tagHex, dataHex] = payload.split(':');
  const decipher = crypto.createDecipheriv(ALGO, KEY, Buffer.from(ivHex, 'hex'));
  decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
  return decipher.update(Buffer.from(dataHex, 'hex')) + decipher.final('utf8');
}
```

Aplique em CPF, CNS, e qualquer campo de identificação direta. Use um
**Prisma middleware** para cifrar/decifrar automaticamente.

### Criptografia em nível de banco
- PostgreSQL com **TDE** (via extensão ou disco criptografado LUKS/EBS encryption).
- TLS obrigatório na conexão: `?sslmode=require` na `DATABASE_URL`.

### Em trânsito
- HTTPS obrigatório (TLS 1.2+). Use proxy reverso (Nginx/Traefik) com Let's Encrypt.
- HSTS habilitado.

---

## 3. Controle rigoroso de acessos

- **RBAC** via `RolesGuard` + decorator `@Roles()` — 7 perfis distintos.
- Princípio do menor privilégio: `DIGITADOR` não acessa diagnóstico; `AGENTE` só visita domiciliar.
- Escopo por município: todo dado é filtrado por `municipalityId` do token.
- **Auditoria completa**: `AuditLog` registra ação, entidade, dados antes/depois, IP e user-agent.

```ts
// Interceptor de auditoria (resumo)
await prisma.auditLog.create({
  data: { userId, action, entity, entityId, oldData, newData, ipAddress, userAgent },
});
```

---

## 4. Direitos do titular (LGPD)

| Direito | Implementação |
|---------|---------------|
| Acesso (art. 18, II) | Endpoint `GET /lgpd/meus-dados` exporta todos os dados do titular |
| Portabilidade | Exportação JSON/PDF do prontuário |
| Eliminação | Soft-delete (`isActive`) + rotina de anonimização após prazo legal |
| Revogação de consentimento | Flag `consentGiven` + log de consentimento |

> ⚠️ Prontuário médico tem **guarda mínima de 20 anos** (Resolução CFM 1.821/2007),
> que prevalece sobre o direito de eliminação durante esse período.

---

## 5. Checklist de conformidade

- [ ] MFA habilitado para todos os perfis com acesso clínico
- [ ] CPF/CNS criptografados em repouso
- [ ] TLS em trânsito (HTTPS + DB SSL)
- [ ] Auditoria ativa e imutável
- [ ] Política de retenção configurada (20 anos para prontuário)
- [ ] DPO/encarregado designado
- [ ] Relatório de Impacto à Proteção de Dados (RIPD) elaborado
- [ ] Backup criptografado (ver `BACKUP_DR.md`)

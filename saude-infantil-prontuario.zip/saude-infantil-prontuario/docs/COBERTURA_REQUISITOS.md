# Cobertura de Requisitos — Sistema Municipal de Saúde

Mapeamento de cada especificação trazida para o componente que a implementa.
Legenda: ✅ implementado · 🔧 estrutura pronta (requer config de infra) · 📋 documentado

---

## Funcionalidades clínicas e de gestão

| # | Requisito | Status | Onde |
|---|-----------|--------|------|
| 1 | Cadastro de pacientes | ✅ | `Child` (Prisma) · `children` module · `IdentificacaoSection.tsx` |
| 2 | Qualificação de dados (limpar/validar) | ✅ | `data-quality/data-quality.service.ts` — valida CNS, CPF, CID-10, detecta duplicatas e inconsistências; gera *quality score* |
| 3 | Gestão de consultas e tratamentos + histórico | ✅ | `prontuario.service.ts` (10 pontos) · timeline cronológica |
| 4 | Relatórios / BPA dinâmico | ✅ | `bpa/bpa.service.ts` + `reports/reports.service.ts` |
| 5 | Atendimento automatizado (assistente virtual) | ✅ | `assistant/assistant.service.ts` + `AssistantChat.tsx` (FAQ + IA Claude) |
| 6 | Acompanhamento de atendimentos (status/previsão) | ✅ | `assistant.service.ts → attendanceStatus()` · `Appointment.status` |
| 7 | Consultas e exames agendados (visualização) | ✅ | `Appointment` model · `assistant → myAppointments()` |
| 8 | Atenção especializada e encaminhamentos | ✅ | `Referral` model · módulo de regulação (PENDENTE→REGULADO→AGENDADO→REALIZADO) |
| 9 | BPA Individualizado e Consolidado (SIASUS) | ✅ | `bpa.service.ts` — arquivo magnético `01/02/03` + campo de controle |
| 10 | Relatórios individuais/consolidados + ficha impressa | ✅ | `bpa.service.ts → getProductionReport()` (por profissional) · PDF de ficha |
| 11 | Atendimentos integrados — equipe multiprofissional | ✅ | `Professional` (CBO, conselho, especialista) · `HealthUnit` |

---

## Requisitos não-funcionais

| # | Requisito | Status | Abordagem |
|---|-----------|--------|-----------|
| 12 | Responsividade total | 🔧 | TailwindCSS mobile-first; breakpoints `sm/md/lg` aplicados nos componentes |
| 13 | UX otimizada por perfil | 🔧 | 7 perfis (`Role`) controlam menus e permissões (`RolesGuard`) |
| 14 | Arquitetura escalável | 🔧 | Microsserviços (backend/frontend/IA) · Docker · stateless JWT · pronto p/ Kubernetes |
| 15 | Alta performance (< 2s) | 🔧 | Índices Prisma (`@@index`), paginação, queries seletivas; ver `monitoring` |
| 16 | Segurança / LGPD (cripto, MFA, acessos) | 🔧 | JWT + `RolesGuard` + `AuditLog`; ver `docs/SEGURANCA_LGPD.md` para MFA e cripto |
| 17 | Backup e recuperação de desastres | 📋 | `docs/BACKUP_DR.md` — `pg_dump` agendado + PITR + retenção |
| 18 | Compatibilidade multiplataforma | 🔧 | Next.js (Chrome/Firefox/Safari/Edge) · PWA pronto p/ iOS/Android |
| 19 | Atualizações e manutenção contínuas | 📋 | CI/CD (GitHub Actions) + versionamento semântico |
| 20 | Alta eficiência em grandes volumes | 🔧 | Connection pooling, índices, processamento BPA em lote por competência |
| 21 | Consultoria técnica / interpretação de dados | ✅ | IA epidemiológica (`/epidemiological`) + indicadores BPA |
| 22 | Monitoramento diário dos dados | ✅ | `monitoring/monitoring.service.ts` — job diário de integridade + alertas |

---

## Detalhes do BPA (SIASUS/MS)

O gerador segue o layout do arquivo magnético do SIA/SUS:

- **Cabeçalho (`01`)**: `#BPA#` + competência (AAAAMM) + nº linhas + nº folhas + campo de controle + órgão origem/destino + CNPJ + versão.
- **BPA-C (`02`)**: produção consolidada agregada por procedimento + CBO + faixa etária.
- **BPA-I (`03`)**: produção individualizada com CNS do paciente, CNS do profissional, CBO, CID-10, procedimento SIGTAP.
- **Campo de controle**: `(Σ códigos de procedimento) % 1111 + 1111`, domínio `[1111..2221]`.

> ⚠️ **Validação obrigatória antes de produção:** as larguras exatas de cada campo e a string de versão variam por competência. Baixe o `Layout_Exportacao_BPA.pdf` da competência-alvo no Portal do SIA (sia.datasus.gov.br) e confira posição a posição. A tabela de procedimentos deve vir do SIGTAP vigente.

---

## Próximos passos sugeridos

1. Rodar `prisma migrate` incluindo `schema-extensions.prisma`.
2. Importar tabela SIGTAP e CNES da competência atual.
3. Configurar MFA (TOTP) e criptografia em repouso (ver docs).
4. Validar layout BPA contra o PDF oficial da competência.
5. Configurar pipeline de backup automatizado.

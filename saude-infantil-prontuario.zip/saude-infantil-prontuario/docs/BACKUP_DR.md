# Backup & Recuperação de Desastres (DR)

Garante integridade e continuidade das operações com backups regulares e
recuperação rápida.

---

## Estratégia 3-2-1

- **3** cópias dos dados
- **2** mídias diferentes
- **1** cópia off-site (nuvem/outro datacenter)

---

## 1. Backup lógico diário (pg_dump)

```bash
#!/bin/bash
# scripts/backup.sh — agendar no cron: 0 2 * * *
set -e
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR=/backups
DB=saude_infantil

# Dump comprimido e criptografado
pg_dump -U postgres -d $DB -F c \
  | gpg --encrypt --recipient backup@saude.gov.br \
  > "$BACKUP_DIR/${DB}_${DATE}.dump.gpg"

# Upload off-site (S3 com criptografia server-side)
aws s3 cp "$BACKUP_DIR/${DB}_${DATE}.dump.gpg" \
  "s3://saude-backups/${DB}/" --sse AES256

# Retenção: manter 30 dias locais, 1 ano off-site
find "$BACKUP_DIR" -name "*.dump.gpg" -mtime +30 -delete
```

Restauração:
```bash
gpg --decrypt backup.dump.gpg | pg_restore -U postgres -d saude_infantil --clean
```

---

## 2. Point-in-Time Recovery (PITR)

Para RPO próximo de zero, habilite WAL archiving:

```conf
# postgresql.conf
wal_level = replica
archive_mode = on
archive_command = 'aws s3 cp %p s3://saude-wal/%f'
```

Permite restaurar o banco para qualquer segundo específico antes de um incidente.

---

## 3. Alta disponibilidade

- **Réplica streaming** (hot standby) em outra zona de disponibilidade.
- **Failover automático** com Patroni + etcd ou serviço gerenciado (RDS Multi-AZ).
- Health checks no `docker-compose.yml` já configurados para o Postgres.

---

## 4. Métricas-alvo

| Métrica | Alvo |
|---------|------|
| RPO (perda máxima de dados) | ≤ 5 min (com PITR) |
| RTO (tempo de recuperação) | ≤ 1 hora |
| Frequência de backup completo | Diária |
| Teste de restauração | Mensal |

---

## 5. Plano de teste de DR

1. Restaurar o último backup em ambiente isolado — **mensalmente**.
2. Validar integridade (contagem de registros, checksums).
3. Simular failover da réplica — **trimestralmente**.
4. Documentar tempo real de recuperação e ajustar.

> Backup sem teste de restauração não é backup. Agende e execute os testes.
